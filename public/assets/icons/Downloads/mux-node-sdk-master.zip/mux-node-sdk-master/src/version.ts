export const VERSION = '7.3.0' as const;
