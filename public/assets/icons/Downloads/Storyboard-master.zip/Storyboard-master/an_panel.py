import bpy
from bpy.types import Panel


class STORYBOARD_PT_animatic(Panel):
    """Creates a Panel in the Tool Shelf with the Storyboard panel.
    These buttons are mainly used for working with timing and
    navigation of the timeline.
    """
    bl_label = " "
    bl_idname = "SCENE_PT_animatic"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Storyboard'
    bl_options = {'DEFAULT_CLOSED'}    # Panel will be collapsed

    def draw_header(self, context):
        layout = self.layout
        row = layout.row()
        row.label(text="Animatic", icon='TIME')

    def draw(self, context):
        layout = self.layout
        sb_data = bpy.context.scene.sb_data
        preferences = bpy.context.preferences.addons[__package__].preferences
        markerslocked = bpy.context.scene.tool_settings.lock_markers

        row = layout.row()
        row.operator('storyboard.viewshotlist')
        row = layout.row()
        row.operator('boards.updatetexteditor',
                     text="Update Text Editor", icon='RECOVER_LAST')

        # if boards.marker_op == 'NAV':
        layout.label(text="Marker Navigation", icon='ARROW_LEFTRIGHT')
        row = layout.row()
        if preferences.bigbuttons:
            row.scale_y = 1.5
        row.operator('boards.marknavprev',
                     text="Previous", icon='TRIA_LEFT')
        row.operator('boards.marknavnext',
                     text="Next", icon='TRIA_RIGHT')
        # if boards.marker_op == 'SEL':
        layout.label(text="Marker Selection", icon='PMARKER_ACT')
        row = layout.row()
        if preferences.bigbuttons:
            row.scale_y = 1.5
        row.enabled = not markerslocked
        row.operator('boards.selmarkafter', text="Pick Markers", icon='FORWARD')
        row = layout.row()
        row.scale_y = 1
        row.operator('storyboard.markall', text="All")
        row.operator('storyboard.marknone', text="None")


class STORYBOARD_PT_markers(Panel):
    """Creates a Panel in the Tool Shelf with the Storyboard panel.
    These are the markers in the current scene.
    """
    bl_label = " "
    bl_idname = "SCENE_PT_AnimaticSub"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Storyboard'
    bl_parent_id = 'SCENE_PT_animatic'   # will be a sub-panel
    bl_options = {'DEFAULT_CLOSED'}    # Panel will be collapsed

    def draw_header(self, context):
        layout = self.layout
        row = layout.row()
        row.label(text="Markers", icon='PMARKER_SEL')

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        markerslocked = scene.tool_settings.lock_markers
        storyboard = bpy.context.scene.sb_data
        mlist = scene.timeline_markers
        markselected = []
        markname = ""
        marktimechange = False
        sbswapsafe = False
        markerlist = sorted(mlist, key=lambda mlist: mlist.frame)
        for m in markerlist:
            if m.select:
                markselected.append(m)
        if len(markselected) > 0:
            marktimechange = True
        row = layout.row()
        row.enabled = marktimechange
        # row.operator('storyboard.marktimechange', text="Change Time Jump", icon='MOD_TIME')
        row.operator('storyboard.marktimechange', icon='MOD_TIME')
        if len(markselected) == 2:
            sbswapsafe = True
        row = layout.row()
        allok = sbswapsafe and not markerslocked
        row.enabled = allok
        row.operator('boards.markerswap',
                     text="Swap Markers", icon="FILE_REFRESH")
        layout.label(text="List of Markers in Scene:  "+str(len(markerlist)))
        row = layout.row()
        row.prop(storyboard, 'marker_view', expand=True)
        # if len(markerlist) > 10:
        #     row = layout.row()
        #     row.prop(storyboard, 'mark_banks', expand=True)
        txtselect = "Markers selected: " + str(len(markselected))
        row = layout.row()
        cola = row.column()
        cola.label(text=txtselect)
        colb = row.column()
        colb.alignment = 'RIGHT'
        colb.enabled = not context.scene.tool_settings.lock_markers
        colb.prop(storyboard, 'marker_ui_frames', text="", icon='ACTION_TWEAK')
        colc = row.column()
        if scene.tool_settings.lock_markers:
            lock = 'LOCKED'
        else:
            lock = 'UNLOCKED'
        colc.prop(scene.tool_settings, 'lock_markers', text="", icon=lock)
        if len(markerlist) > 0:
            for mark in markerlist:
                marker_view = True
                img = 'PMARKER_SEL'
                chekbox = 'CHECKBOX_DEHLT'
                if scene.frame_current == mark.frame:
                    img = 'PMARKER_ACT'
                if mark.select:
                    # img = 'PMARKER_ACT'
                    chekbox = 'CHECKBOX_HLT'
                txt = mark.name
                if txt[0:3].lower() == "mus":
                    img = 'FILE_SOUND'
                if txt[0:3].lower() == "act":
                    img = 'ARMATURE_DATA'
                if txt[0:2].lower() == "fx":
                    img = 'SHADERFX'
                if mark.camera:
                    if storyboard.marker_view == 'MARKERS':
                        marker_view = False
                    img = 'OUTLINER_DATA_CAMERA'
                    if scene.frame_current == mark.frame:
                        img = 'VIEW_CAMERA'
                    if mark.select:
                        # img = 'VIEW_CAMERA'
                        chekbox = 'CHECKBOX_HLT'
                    txt = mark.camera.name
                elif storyboard.marker_view == 'CAMERAS':
                    marker_view = False
                if marker_view:
                    row = self.layout.row()
                    plate = row.operator('boards.marknavjump',
                                         text=txt, icon=img)
                    plate.frame = mark.frame
                    if not context.scene.tool_settings.lock_markers:
                        if storyboard.marker_ui_frames:
                            row.prop(mark, 'frame', text="")
                        row.prop(mark, 'select', text="")

        else:
            layout.label(text="No markers in current scene")


class STORYBOARD_PT_input(Panel):
    """Creates a Panel in the Tool Shelf.
    Import images and objects.
    """
    bl_label = " "
    bl_idname = "SCENE_PT_Input"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Storyboard'
    bl_options = {'DEFAULT_CLOSED'}    # Panel will be collapsed

    def draw_header(self, context):
        layout = self.layout
        row = layout.row()
        row.label(text="Input")
        # row.label(text="Input", icon='FILEBROWSER')

    def draw(self, context):
        scene = context.scene
        path_valid = False
        board_list = bpy.data.collections['Storyboard_Panels']
        storyboard = bpy.context.scene.sb_data
        preferences = bpy.context.preferences.addons[__package__].preferences
        layout = self.layout
        col = layout.column(align=True)
        if not storyboard.created:
            col.label(text="Create Storyboard First")
        else:
            col.label(text="Group Image Import")
            col = layout.column(align=True)
            col.prop(storyboard, 'images_path')
            if not storyboard.images_path == "//":
                path_valid = True
            row = layout.row()
            row.enabled = path_valid
            row.operator('import_scene.boards_images', text="Load Images to Panels", icon='IMAGE_DATA')
            if preferences.seefuture:
                row = layout.row()
                row.label(text="Single Image Import")
                row = layout.row()
                # row.active = path_valid
                # row.prop_search(scene, "panelLoadImage", scene, "objects")
                row.prop_search(scene, "panelLoadImage", board_list, "objects")
                row = layout.row()
                # row.enabled = path_valid
                row.enabled = False
                row.operator('boards.import_one_image', text="Load Image to Panel", icon='IMAGE_DATA')


class STORYBOARD_PT_output(Panel):
    """Creates a Panel in the Tool Shelf with the Storyboard panel.
    These buttons are mainly used for working with timing and
    navigation of the timeline.
    """
    bl_label = " "
    bl_idname = "SCENE_PT_export"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Storyboard'
    bl_options = {'DEFAULT_CLOSED'}    # Panel will be collapsed

    def draw_header(self, context):
        layout = self.layout
        row = layout.row()
        row.label(text="Output")
        # row.label(text="Output", icon='FILEBROWSER')

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        storyboard = bpy.context.scene.sb_data
        preferences = bpy.context.preferences.addons[__package__].preferences

        row = layout.row()
        row.operator('sboutput.exportmarkers',
                     text="Export Marker List", icon='MARKER_HLT')

        row = layout.row()
        row.operator('sboutput.viewportrender',
                     text="Viewport Render Markers", icon='RENDER_ANIMATION')

        row = layout.row()
        row.operator('sboutput.rendermarkers',
                     text="Render Marker Images", icon='RENDER_STILL')

        row = layout.row()
        row.enabled = storyboard.created
        row.operator('storyboard.rendersbviews', icon='OUTLINER_OB_CAMERA')

        if preferences.seefuture:
            row = layout.row()
            row.enabled = False
            row.operator('sboutput.rendermarkers', text="Export PDF", icon='DOCUMENTS')


classes = (
    STORYBOARD_PT_animatic,
    STORYBOARD_PT_markers,
    STORYBOARD_PT_input,
    STORYBOARD_PT_output,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in classes:
        bpy.utils.unregister_class(cls)
