# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

from bpy.types import Operator
from . import sb_panel
from . import an_panel
from . import boards_op
from . import gpencil_op
from . import guides_op
from . import output_op
from . import properties
import os
import bpy

bl_info = {
    "name": "Storyboard",
    "author": "Edward S. White",
    "description": "A suite of tools for creating storyboards and animatics",
    "blender": (2, 82, 0),
    "version": (0, 9, 96),
    "location": "View3D > Sidebar > Storyboard",
    "doc_url": "https://edwardswhite.gitbook.io/storyboard-animatic/",
    "category": "3D View"
}

classes = (
)


def register():
    sb_panel.register()
    an_panel.register()
    properties.register()
    boards_op.register()
    gpencil_op.register()
    guides_op.register()
    output_op.register()
    for cls in classes:
        bpy.utils.register_class(cls)


def unregister():
    an_panel.unregister()
    sb_panel.unregister()
    properties.unregister()
    boards_op.unregister()
    gpencil_op.unregister()
    guides_op.unregister()
    output_op.unregister()
    for cls in classes:
        bpy.utils.unregister_class(cls)


if __name__ == "__main__":
    register()
