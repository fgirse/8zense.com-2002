import bpy
from bpy.props import StringProperty, BoolProperty, EnumProperty
from bpy.types import Operator
from bpy_extras.io_utils import ExportHelper
# from . import sb_panel


def ShowMessageBox(message="", title="Message Box", icon='INFO'):

    def draw(self, context):
        self.layout.label(text=message)

    bpy.context.window_manager.popup_menu(draw, title=title, icon=icon)


def ShowMessageListBox(message="", list=[], title="Message Box", icon='INFO'):

    def draw(self, context):
        self.layout.label(text=message)
        for l in list:
            self.layout.label(text=l)

    bpy.context.window_manager.popup_menu(draw, title=title, icon=icon)


def make_key_markers():
    # Create keyframes for each marker in the timeline
    scene = bpy.context.scene

    # Create a variable to store Y rotation values
    y_spinner = 0.0

    # Deselect all
    bpy.ops.object.select_all(action='DESELECT')

    # Add an empty object for setting keyframes
    bpy.ops.object.empty_add(type='SINGLE_ARROW', align='WORLD')

    # Scale the empty down to make it almost invisible
    bpy.context.object.scale = (0.000001, 0.000001, 0.000001)

    # Get list of all markers in the scene
    mlist = bpy.context.scene.timeline_markers

    # sort markers by time
    markerlist = sorted(mlist, key=lambda mlist: mlist.frame)

    # step through markers and save a keyframe on the empty (use Y rotation)
    for m in markerlist:
        scene.frame_current = m.frame
        y_spinner += 0.0174533
        bpy.context.object.rotation_euler[1] = y_spinner
        bpy.context.object.keyframe_insert(
            data_path="rotation_euler", frame=m.frame)


def export_marker_list(context, filepath, settings, options):
    camlist = []
    print("Exporting markers list...")
    scene_name = bpy.context.scene.name
    scene_fps = bpy.context.scene.render.fps
    scene_res_x = bpy.context.scene.render.resolution_x
    scene_res_y = bpy.context.scene.render.resolution_y
    mlist = bpy.context.scene.timeline_markers
    markerlist = sorted(mlist, key=lambda mlist: mlist.frame)
    for m in markerlist:
        shotinfo = ""
        if settings and options == 'ALL':
            shotinfo = str(m.frame) + "\t "
        if settings and options == 'CAMERAS_ONLY' and m.camera:
            shotinfo = str(m.frame) + "\t "

        if options == 'ALL':
            shotinfo += m.name + "\t"
            if m.camera:
                shotinfo += m.camera.name

        else:
            if m.camera:
                shotinfo += m.name + "\t" + m.camera.name

        if shotinfo:
            shotinfo += "\n"
        camlist.append(shotinfo)

    f = open(filepath, 'w', encoding='utf-8')
    f.write("SCENE NAME: %s\n" % scene_name)
    f.write("FPS: %s\n" % scene_fps)
    f.write("RES_X: %s\n" % scene_res_x)
    f.write("RES_Y: %s\n\n" % scene_res_y)
    if settings:
        f.write("FRAME\tMARKER \tCAMERA\n")
    else:
        f.write("MARKER \tCAMERA\n")
    for c in camlist:
        f.write(c)
    f.close()
    print("Exported markers list")
    ShowMessageBox("Finished Exporting",
                   "Export Marker List",
                   'INFO')

    return {'FINISHED'}


class STORYBOARD_OT_exportmarkers(bpy.types.Operator, ExportHelper):
    """Export list of markers from the current scene"""
    bl_idname = "sboutput.exportmarkers"
    bl_label = "Export Marker List"
    bl_description = "Export list of markers from the current scene"

    # ExportHelper mixin class uses this
    filename_ext = ".txt"

    filter_glob: StringProperty(
        default="*.txt",
        options={'HIDDEN'},
        maxlen=255,  # Max internal buffer length, longer would be clamped.
    )

    # List of operator properties, the attributes will be assigned
    # to the class instance from the operator settings before calling.
    use_setting: BoolProperty(
        name="Include Frame Numbers",
        description="Export frame numbers with marker list",
        default=True,
    )

    type: EnumProperty(
        name="Marker List",
        description="Choose which type of markers to export",
        items=(
            ('ALL', "All Markers",
             "All markers will be exported"),
            ('CAMERAS_ONLY', "Only Bound Cameras",
             "Only markers with bound cameras"),
            # ('MARKERS_ONLY', "Only Markers",
            #  "Only markers, NO cameras"),
            # ('MARKERS_NAMED', "Only Markers Tagged",
            #  "Only markers with special names"),
        ),
        default='CAMERAS_ONLY',
    )

    def execute(self, context):
        # Get list of all markers in the scene
        mlist = bpy.context.scene.timeline_markers
        if len(mlist) == 0:
            print("No markers in the current scene.")
            ShowMessageBox("No markers in the current scene.",
                           "Export Marker List",
                           'ERROR')
            return {'FINISHED'}

        return export_marker_list(context, self.filepath, self.use_setting, self.type)


class STORYBOARD_OT_modalvranimmarks(Operator):
    """Viewport render holding on timeline marker positions"""
    bl_idname = "sboutput.viewportrender"
    bl_label = "Viewport Render Holding on Markers"
    bl_description = "Viewport render holding on timeline marker positions"

    _timer = None
    scene = None
    markers = None
    renderpath = None
    prevpath = None
    prevframe = None
    stop = None
    rendering = None

    def vrmcancel(self, dummy, thrd=None):
        self.scene.frame_current = self.prevframe
        self.scene.render.filepath = self.prevpath
        print("Cancelled")
        self.stop = True

    def draw(self, context):

        layout = self.layout
        row = layout.row()
        row.label(text="Output file location")

        row = layout.row()
        row.label(text="Press Esc if location is not correct.")

        file_path = bpy.context.scene.render.filepath
        box = layout.box()
        row = box.row()
        row.alignment = 'LEFT'
        row.label(text=file_path)

    def invoke(self, context, event):

        scene = bpy.context.scene
        self.scene = scene
        # Check for not a image format
        animation_formats = ['FFMPEG', 'AVI_JPEG', 'AVI_RAW']
        if not scene.render.image_settings.file_format in animation_formats:
            print("Image file formats are not supported.")
            ShowMessageBox("Image file formats are not supported.",
                           "Viewport Render Holding on Markers",
                           'ERROR')
            return {'FINISHED'}
        # Get list of all markers in the scene
        mlist = scene.timeline_markers
        if not mlist:
            print("No markers in the current scene.")
            ShowMessageBox("No markers in the current scene.",
                           "Viewport Render",
                           'ERROR')
            return {'FINISHED'}
        self.markers = sorted(mlist, key=lambda mlist: mlist.frame)
        self.renderpath = scene.render.filepath
        self.prevpath = scene.render.filepath
        self.prevframe = scene.frame_current

        return context.window_manager.invoke_props_dialog(self)

    def execute(self, context):

        bpy.app.handlers.render_cancel.append(self.vrmcancel)

        scene = bpy.context.scene
        wm = bpy.context.window_manager
        self._timer = wm.event_timer_add(0.1, window=bpy.context.window)
        wm.modal_handler_add(self)

        return {"RUNNING_MODAL"}

    def modal(self, context, event):

        if event.type in {'ESC'}:
            self.vrmcancel(context)
            return {'CANCELLED'}

        if event.type == 'TIMER':
            if True in (not self.markers, self.stop is True):
                bpy.app.handlers.render_cancel.remove(self.vrmcancel)
                bpy.context.window_manager.event_timer_remove(self._timer)
                bpy.context.scene.frame_current = self.prevframe
                bpy.context.scene.render.filepath = self.prevpath
                ShowMessageBox("Finished Rendering",
                               "Viewport Render Holding on Markers",
                               'INFO')
                return {"FINISHED"}

            elif not self.rendering:
                scene = bpy.context.scene
                scene.render.filepath = self.renderpath + "_"
                scene.frame_current = scene.frame_start
                make_key_markers()
                bpy.ops.render.opengl(animation=True, render_keyed_only=True)
                bpy.ops.object.delete(use_global=False)
                self.stop = True

        return {"PASS_THROUGH"}


class STORYBOARD_OT_rendermarkers(Operator):
    """Render images only at timeline marker positions"""
    bl_idname = "sboutput.rendermarkers"
    bl_label = "Render Markers"
    bl_description = "Render images only at timeline marker positions"

    _timer = None
    scene = None
    markers = None
    prevpath = None
    renderpath = None
    prevframe = None
    timeframe = None
    stop = None
    rendering = None

    def rmpre(self, dummy, thrd=None):
        self.rendering = True

    def rmpost(self, context, thrd=None):
        self.markers.pop(0)
        if len(self.markers):
            self.timeframe = self.markers[0].frame
        else:
            self.stop = True
        bpy.context.scene.frame_current = self.timeframe
        self.rendering = False

    def rmcancel(self, dummy, thrd=None):
        self.scene.frame_current = self.prevframe
        self.scene.render.filepath = self.prevpath
        print("Cancelled")
        self.stop = True

    def execute(self, context):

        bpy.app.handlers.render_pre.append(self.rmpre)
        bpy.app.handlers.render_post.append(self.rmpost)
        bpy.app.handlers.render_cancel.append(self.rmcancel)

        scene = bpy.context.scene
        self.scene = scene
        # Save current scene settings
        self.renderpath = scene.render.filepath
        self.prevpath = scene.render.filepath
        self.prevframe = scene.frame_current
        # scene.frame_current
        # Get list of all markers in the scene
        mlist = scene.timeline_markers
        # sort markers by time
        self.markers = sorted(mlist, key=lambda mlist: mlist.frame)
        self.timeframe = self.markers[0].frame

        wm = bpy.context.window_manager
        self._timer = wm.event_timer_add(0.1, window=bpy.context.window)
        wm.modal_handler_add(self)

        return {'RUNNING_MODAL'}

    def modal(self, context, event):

        if event.type in {'ESC'}:
            self.rmcancel(context)
            return {'CANCELLED'}

        if event.type == 'TIMER':
            if True in (not self.markers, self.stop is True):
                bpy.app.handlers.render_pre.remove(self.rmpre)
                bpy.app.handlers.render_post.remove(self.rmpost)
                bpy.app.handlers.render_cancel.remove(self.rmcancel)
                bpy.context.window_manager.event_timer_remove(self._timer)
                bpy.context.scene.frame_current = self.prevframe
                bpy.context.scene.render.filepath = self.prevpath
                ShowMessageBox("Finished Rendering",
                               "Render Images at Markers",
                               'INFO')
                return {"FINISHED"}

            elif not self.rendering:
                scene = bpy.context.scene
                # render images holding for each marker
                scene.render.filepath = self.renderpath + "_" + \
                    str(self.timeframe).zfill(4)
                bpy.ops.render.render(animation=False,
                                      write_still=True
                                      )

        return {'PASS_THROUGH'}

    def draw(self, context):

        layout = self.layout
        row = layout.row()
        row.label(text="Output file location")

        row = layout.row()
        row.label(text="Press Esc if location is not correct.")

        file_path = bpy.context.scene.render.filepath
        box = layout.box()
        row = box.row()
        row.alignment = 'LEFT'
        row.label(text=file_path)

    def invoke(self, context, event):

        scene = bpy.context.scene
        animation_formats = ['FFMPEG', 'AVI_JPEG', 'AVI_RAW', 'FRAMESERVER']
        if scene.render.image_settings.file_format in animation_formats:
            print("Movie file formats are not supported in Render Markers.")
            ShowMessageBox("Movie file formats are not supported.",
                           "Render Images at Markers",
                           'ERROR')
            return {'FINISHED'}
        # Get list of all markers in the scene
        mlist = scene.timeline_markers
        if not mlist:
            print("No markers in the current scene.")
            ShowMessageBox("No markers in the current scene.",
                           "Viewport Render Images at Markers",
                           'ERROR')
            return {'FINISHED'}
        return context.window_manager.invoke_props_dialog(self)


class STORYBOARD_OT_renderanimmarkers(Operator):
    """Render the same frame until a new marker is reached"""
    bl_idname = "sboutput.renderanimmarkers"
    bl_label = "Render Markers"
    bl_description = "Render the same frame until a new marker is reached"

    _timer = None
    scene = None
    markers = None
    renderpath = None
    prevpath = None
    prevframe = None
    timeframe = None
    totalframe = None
    stop = None
    rendering = None

    def rampre(self, dummy, thrd=None):
        self.rendering = True

    def rampost(self, context, thrd=None):
        self.timeframe += 1
        for m in self.markers:  # check if new marker has been reached
            if self.timeframe == m.frame:
                bpy.context.scene.frame_current = self.timeframe
        if self.timeframe > bpy.context.scene.frame_end:
            self.stop = True
        self.scene.render.filepath = self.prevpath
        self.rendering = False

    def ramcancel(self, dummy, thrd=None):
        self.scene.frame_current = self.prevframe
        self.scene.render.filepath = self.prevpath
        print("Cancelled")
        self.stop = True

    def execute(self, context):

        bpy.app.handlers.render_pre.append(self.rampre)
        bpy.app.handlers.render_post.append(self.rampost)
        bpy.app.handlers.render_cancel.append(self.ramcancel)

        scene = bpy.context.scene
        # Get list of all markers in the scene
        mlist = scene.timeline_markers
        self.markers = sorted(mlist, key=lambda mlist: mlist.frame)
        self.renderpath = scene.render.filepath
        self.prevpath = scene.render.filepath
        self.prevframe = scene.frame_current
        self.timeframe = scene.frame_start
        self.totalframe = scene.frame_end - scene.frame_start
        scene.frame_current = self.timeframe

        wm = bpy.context.window_manager
        self._timer = wm.event_timer_add(0.1, window=bpy.context.window)
        wm.modal_handler_add(self)

        return {"RUNNING_MODAL"}

    def modal(self, context, event):

        if event.type in {'ESC'}:
            self.ramcancel(context)
            return {'CANCELLED'}

        if event.type == 'TIMER':
            if True in (not self.markers, self.stop is True):
                bpy.app.handlers.render_pre.remove(self.rampre)
                bpy.app.handlers.render_post.remove(self.rampost)
                bpy.app.handlers.render_cancel.remove(self.ramcancel)
                bpy.context.window_manager.event_timer_remove(self._timer)
                bpy.context.scene.frame_current = self.prevframe
                bpy.context.scene.render.filepath = self.prevpath
                ShowMessageBox("Finished Rendering",
                               "Render Holding on Markers",
                               'INFO')
                return {"FINISHED"}

            elif not self.rendering:
                scene = bpy.context.scene
                # render images holding for each marker
                scene.render.filepath = self.renderpath + "_" + \
                    str(self.timeframe).zfill(4)
                bpy.ops.render.render(animation=False,
                                      write_still=True
                                      )

        return {'PASS_THROUGH'}

    def draw(self, context):

        layout = self.layout
        row = layout.row()
        row.label(text="Output File Location")

        row = layout.row()
        row.label(text="Press Esc if location is not correct.")

        file_path = bpy.context.scene.render.filepath
        box = layout.box()
        row = box.row()
        row.alignment = 'LEFT'
        row.label(text=file_path)

    def invoke(self, context, event):

        scene = bpy.context.scene
        self.scene = scene
        # Check for not a movie format
        animation_formats = ['FFMPEG', 'AVI_JPEG', 'AVI_RAW']
        if scene.render.image_settings.file_format in animation_formats:
            print("Movie file formats are not supported in Render Markers.")
            ShowMessageBox("Movie file formats are not supported.",
                           "Render Holding on Markers",
                           'ERROR')
            return {'FINISHED'}
        # Get list of all markers in the scene
        mlist = scene.timeline_markers
        if not mlist:
            print("No markers in the current scene.")
            ShowMessageBox("No markers in the current scene.",
                           "Viewport Render Images at Markers",
                           'ERROR')
            return {'FINISHED'}
        return context.window_manager.invoke_props_dialog(self)


class STORYBOARD_OT_rendersbviews(Operator):
    """Render the Storyboard camera views"""
    bl_idname = "storyboard.rendersbviews"
    bl_label = "Render Storyboard Camera"
    bl_description = "Render the Storyboard camera views"

    _timer = None
    scene = None
    markers = None
    render_sbcamviews = []
    rendered_names = []
    prevcam = None
    prevpath = None
    renderpath = None
    prevframe = None
    timeframe = None
    rendername = None
    pseudo_index = 0
    stop = None
    rendering = None

    def rmpre(self, dummy, thrd=None):
        self.rendering = True

    def rmpost(self, context, thrd=None):
        self.rendered_names.append(self.render_sbcamviews[0].name)
        self.render_sbcamviews.pop(0)
        if len(self.render_sbcamviews):
            self.timeframe = self.render_sbcamviews[0].frame
            self.rendername = self.render_sbcamviews[0].name
            # Change Camera HERE
        else:
            self.stop = True
        bpy.context.scene.frame_current = self.timeframe
        self.rendering = False

    def rmcancel(self, dummy, thrd=None):
        self.scene.frame_current = self.prevframe
        self.scene.render.filepath = self.prevpath
        # Maybe report if some frames rendered HERE
        print("Cancelled")
        self.stop = True

    def execute(self, context):

        bpy.app.handlers.render_pre.append(self.rmpre)
        bpy.app.handlers.render_post.append(self.rmpost)
        bpy.app.handlers.render_cancel.append(self.rmcancel)

        scene = bpy.context.scene
        self.scene = scene
        # Save current scene settings
        self.renderpath = scene.render.filepath
        self.prevpath = scene.render.filepath
        self.prevframe = scene.frame_current
        # Get list of all markers in the scene
        mlist = scene.timeline_markers
        # sort markers by time
        self.markers = sorted(mlist, key=lambda mlist: mlist.frame)
        # Get list of Storyboard camera views
        for c in scene.sb_camviews:
            if c.cam_render:
                # Render Storyboard Camera View
                self.render_sbcamviews.append(c)
        if self.render_sbcamviews:
            self.timeframe = self.render_sbcamviews[0].frame

        wm = bpy.context.window_manager
        self._timer = wm.event_timer_add(0.1, window=bpy.context.window)
        wm.modal_handler_add(self)

        return {'RUNNING_MODAL'}

    def modal(self, context, event):

        if event.type in {'ESC'}:
            self.rmcancel(context)
            return {'CANCELLED'}

        if event.type == 'TIMER':
            if True in (not self.render_sbcamviews, self.stop is True):
                scene = bpy.context.scene
                bpy.app.handlers.render_pre.remove(self.rmpre)
                bpy.app.handlers.render_post.remove(self.rmpost)
                bpy.app.handlers.render_cancel.remove(self.rmcancel)
                bpy.context.window_manager.event_timer_remove(self._timer)
                bpy.context.scene.frame_current = self.prevframe
                bpy.context.scene.render.filepath = self.prevpath
                markerlist = scene.timeline_markers
                sortedmarkers = sorted(markerlist, key=lambda mlist: mlist.frame)
                sortedmarkers[0].camera = self.prevcam
                # Report which views were rendered
                if self.rendered_names:
                    ShowMessageListBox("Finished Rendering Storyboard Camera Views",
                                self.rendered_names,
                                "Render Storyboard Camera",
                                'INFO')
                return {"FINISHED"}

            elif not self.rendering:
                scene = bpy.context.scene
                # scene.render.filepath = self.renderpath + "_" + str(self.timeframe).zfill(4)
                # Render storyboard view
                storyboard_cam = bpy.data.objects['Storyboard']
                if self.render_sbcamviews[0].frame == self.markers[0].frame:
                    print('Marker match!')
                    print(self.markers[0].camera)
                    print(storyboard_cam)
                scene.frame_current = self.render_sbcamviews[0].frame
                storyboard_cam.location = self.render_sbcamviews[0].cam_pos
                storyboard_cam.data.ortho_scale = self.render_sbcamviews[0].ortho_scale
                self.rendername = self.render_sbcamviews[0].name
                print(self.rendername, self.pseudo_index)
                # Temp name of frame number - should be indexnumber
                scene.render.filepath = self.renderpath + "." + str(self.pseudo_index).zfill(4) + "." + self.rendername
                self.pseudo_index += 1
                bpy.ops.render.render(animation=False, write_still=True)

        return {'PASS_THROUGH'}

    def draw(self, context):

        layout = self.layout
        scene = context.scene
        render = scene.render
        storyboard = bpy.context.scene.sb_data
        # preferences = bpy.context.preferences.addons[__package__].preferences

        row = layout.row()
        row.label(text="Press Esc to abort without rendering.")
        file_path = bpy.context.scene.render.filepath
        row = layout.row()
        row.label(text="Output file path:")
        box = layout.box()
        row = box.row()
        row.alignment = 'LEFT'
        row.label(text=file_path)
        box = layout.box()
        row = box.row()
        row.label(text="Render settings")
        row = box.row()
        row.prop(storyboard, "cam_rendersettings", expand=True)
        row = box.row()
        row.alignment = 'RIGHT'
        row.label(text="Resolution X")
        row.prop(render, "resolution_x", text="")
        row = box.row()
        row.alignment = 'RIGHT'
        row.label(text="Y")
        row.prop(render, "resolution_y", text="")

        # if storyboard.cam_rendersettings == 'OPTONE':
        #     render = scene.render
        #     row = box.row()
        #     row.alignment = 'RIGHT'
        #     row.label(text="Resolution X")
        #     row.prop(render, "resolution_x", text="")
        #     row = box.row()
        #     row.alignment = 'RIGHT'
        #     row.label(text="Y")
        #     row.prop(render, "resolution_y", text="")
        
        row = layout.row()
        # row.separator()
        row.label(text="Storyboard Views:")
        rows = 6
        row = layout.row()
        row.template_list("STORYBOARD_UL_storyboard_views", "The_List",
                            scene, "sb_camviews", scene, "sb_cvindex", rows=rows)
        col = row.column(align=True)
        sub = col.column(align=True)
        sub.operator("storyboard.storyboardviews", icon='TRIA_UP', text="").action = 'UP'
        sub.operator("storyboard.storyboardviews", icon='TRIA_DOWN', text="").action = 'DOWN'
        sub.separator()
        sub.menu("STORYBOARD_MT_sbviewsmenu", icon='DOWNARROW_HLT', text="")

    def invoke(self, context, event):
        scene = bpy.context.scene
        self.rendered_names = []
        animation_formats = ['FFMPEG', 'AVI_JPEG', 'AVI_RAW', 'FRAMESERVER']
        if scene.render.image_settings.file_format in animation_formats:
            print("Movie file formats are not supported in Render Markers.")
            ShowMessageBox("Movie file formats are not supported.",
                           "Render Storyboard Camera",
                           'ERROR')
            return {'FINISHED'}
        # Get list of Storyboard views
        render_something = False
        for c in scene.sb_camviews:
            if c.cam_render:
                render_something =True        
        if not render_something:
            print("No Storyboard views set for rendering.")
            ShowMessageBox("No Storyboard views set for rendering.",
                           "Render Storyboard Camera",
                           'ERROR')
            return {'FINISHED'}
        # Fixed Storyboard rendering at frame 1
        markerlist = scene.timeline_markers
        sortedmarkers = sorted(markerlist, key=lambda mlist: mlist.frame)
        if (sortedmarkers[0].frame == 1) and sortedmarkers[0].camera:
            self.prevcam = sortedmarkers[0].camera
            sortedmarkers[0].camera = bpy.data.objects['Storyboard']

        return context.window_manager.invoke_props_dialog(self)


classes = (
    STORYBOARD_OT_exportmarkers,
    STORYBOARD_OT_modalvranimmarks,
    STORYBOARD_OT_rendermarkers,
    STORYBOARD_OT_renderanimmarkers,
    STORYBOARD_OT_rendersbviews,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in classes:
        bpy.utils.unregister_class(cls)
