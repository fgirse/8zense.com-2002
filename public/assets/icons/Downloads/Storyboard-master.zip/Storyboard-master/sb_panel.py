import bpy
from bpy.types import Panel, UIList, Menu


class STORYBOARD_PT_main(Panel):
    """Creates a Panel in the Tool Shelf.
    The main operator is the boards.creation which makes planes in a
    user defined array horizontally (X-axis) and Vertically (Z-axis).
    """
    bl_label = " "
    bl_idname = "SCENE_PT_storyboard"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Storyboard'

    def draw_header(self, context):
        layout = self.layout
        row = layout.row()
        row.label(text="Storyboard", icon='IMGDISPLAY')

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        storyboard = bpy.context.scene.sb_data
        preferences = bpy.context.preferences.addons[__package__].preferences
        mlist = []
        markerlist = []
        cameras = []
        activeobj_name = ""
        obj = bpy.context.active_object
        if not obj:
            activeobj_name = "None"
        else:
            activeobj_name = obj.name
        activecam_name = ""
        cam = bpy.context.scene.camera
        if (cam and cam.type == 'CAMERA'):
            activecam_name = cam.name

        if not storyboard.created:
            row = layout.row()
            row.scale_y = 1.5
            row.operator('boards.creation',
                         text="Create Storyboard", icon='IMGDISPLAY')
        else:
            if storyboard.fast_draw:
                fd_icon = 'CHECKBOX_HLT'
            else:
                fd_icon = 'CHECKBOX_DEHLT'
            row = layout.row()
            if preferences.bigbuttons:
                row.scale_y = 1.5
            row.operator('boards.fastdraw', text="Draw", icon='GREASEPENCIL')
            row.operator('boards.stopdraw', text="Select", icon='RESTRICT_SELECT_OFF')

        row = layout.row()
        row.label(text="Camera Navigation", icon='ARROW_LEFTRIGHT')
        if storyboard.created:
            if storyboard.fast_draw:
                fd_icon = 'CHECKBOX_HLT'
            else:
                fd_icon = 'CHECKBOX_DEHLT'
            row = layout.row()
            row.prop(storyboard, 'fast_draw', icon=fd_icon, emboss=True, text="Fast Draw")

        row = layout.row()
        if preferences.bigbuttons:
            row.scale_y = 1.5
        row.alignment = 'CENTER'
        row.operator('boards.camprev',
                     text="Previous", icon='TRIA_LEFT')
        row.label(text=activecam_name)
        row.operator('boards.camnext', text="Next", icon='TRIA_RIGHT')

        row = layout.row()
        row.label(text="Active Object: ")
        row.label(text=activeobj_name)

        if storyboard.created:
            row = layout.row()
            if preferences.bigbuttons:
                row.scale_y = 1.5
            row.operator('boards.find', text="Jump to Shot")


class STORYBOARD_PT_cameras(Panel):
    """Creates a Panel in the Tool Shelf with the Storyboard panel. 
    These are the cameras in the current scene.
    """
    bl_label = " "
    bl_idname = "SCENE_PT_StoryboardSub"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Storyboard'
    bl_parent_id = 'SCENE_PT_storyboard'   # will be a sub-panel

    def draw_header(self, context):
        layout = self.layout
        row = layout.row()
        row.label(text="Cameras", icon='OUTLINER_DATA_CAMERA')

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        storyboard = bpy.context.scene.sb_data
        scenecam = bpy.context.scene.camera
        mlist = []
        markerlist = []
        allcams = []
        cameras = []

        row = layout.row()
        row.label(text="List of Cameras in Scene")

        row = layout.row()
        row.prop(storyboard, "cam_views", expand=True)

        allcams = [a for a in scene.objects if a.type == 'CAMERA']
        if storyboard.cam_views == 'ALL':
            if len(allcams) > 0:
                for camera in allcams:
                    if camera == scenecam:
                        img = 'VIEW_CAMERA'
                    else:
                        img = 'OUTLINER_DATA_CAMERA'
                    row = layout.row(align=True)
                    row.context_pointer_set("active_object", camera)
                    row.operator("cameraselector.set_shot_camera",
                                 text=camera.name, icon=img)
            else:
                layout.label(text="No cameras in scene")
        else:
            for s in allcams:
                if s.name == "Storyboard":
                    cameras.append(s)

            mlist = scene.timeline_markers
            markerlist = sorted(mlist, key=lambda mlist: mlist.frame)
            for m in markerlist:
                if m.camera:
                    cameras.append(m.camera)

            if len(cameras) > 0:
                for camera in cameras:
                    if camera == scenecam:
                        img = 'VIEW_CAMERA'
                    else:
                        img = 'OUTLINER_DATA_CAMERA'
                    row = layout.row(align=True)
                    row.context_pointer_set("active_object", camera)
                    row.operator("cameraselector.set_shot_camera",
                                 text=camera.name, icon=img)
            else:
                layout.label(text="No cameras bound to markers")


class STORYBOARD_UL_storyboard_views(UIList):

    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):

        # add code to decide which icon to use here...
        if item.cam_active:
            custom_icon = 'OUTLINER_OB_CAMERA'
        else:
            custom_icon = 'OUTLINER_DATA_CAMERA'
        if item.cam_render:
            render_icon = 'RESTRICT_RENDER_OFF'
        else:
            render_icon = 'RESTRICT_RENDER_ON'

        if self.layout_type in {'DEFAULT', 'COMPACT'}:
            row = layout.row()
            # row.prop(item, 'name', text='', icon=custom_icon, emboss=False, translate=False)
            cola = row.column()
            cola.prop(item, 'name', text='', icon=custom_icon, emboss=False, translate=False)
            # colc = row.column()
            # colc.alignment = 'RIGHT'            
            # colc.prop(item, 'frame', text='', emboss=True, translate=False)
            colb = row.column()
            colb.alignment = 'RIGHT'            
            colb.prop(item, 'cam_render', text='', icon=render_icon, emboss=False, translate=False)
        elif self.layout_type in {'GRID'}:
            layout.alignment = 'CENTER'
            layout.label(text="", icon='OUTLINER_OB_CAMERA')


class STORYBOARD_MT_sbviewsmenu(Menu):
    """Control rendering of Storyboard camera views"""
    bl_label = "Storyboard Views Menu"

    def draw(self, context):
        layout = self.layout
        layout.label(text="Storyboard Camera Views")
        layout.separator()
        layout.operator("storyboard.sbviewsmenu", icon='RESTRICT_RENDER_OFF', text="Render All").action = 'RENDERALL'
        layout.operator("storyboard.sbviewsmenu", icon='RESTRICT_RENDER_ON', text="Hide Others").action = 'HIDEOTHERS'
        layout.operator("storyboard.sbviewsmenu", icon='UV_SYNC_SELECT', text="Toggle Renders").action = 'TOGGLERENDERS'


class STORYBOARD_PT_cam_storyboard(Panel):
    """ Put Storyboard camera at center of selected objects """
    bl_label = " "
    bl_idname = "SCENE_PT_CamStoryboard"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Storyboard'
    bl_parent_id = 'SCENE_PT_storyboard'   # will be a sub-panel
    # bl_parent_id = 'SCENE_PT_StoryboardLayout'   # will be a sub-panel
    bl_options = {'DEFAULT_CLOSED'}    # Panel will be collapsed

    def draw_header(self, context):
        layout = self.layout
        row = layout.row()
        row.label(text="Storyboard Camera", icon='OUTLINER_DATA_CAMERA')

    def draw(self, context):

        layout = self.layout
        scene = context.scene
        obj = bpy.context.active_object
        storyboard = bpy.context.scene.sb_data
        if not storyboard.created:
            row = layout.row()
            row.label(text="Create Storyboard First")
        else:
            cam_storyboard = bpy.data.objects['Storyboard'].data
            row = layout.row()
            row.operator('storyboard.centerstoryboard', text='Center on Selected')
            row = layout.row()
            row.prop(cam_storyboard, "ortho_scale", text="Ortho Scale")
            row = layout.row()
            row.label(text="Storyboard Views")
            rows = 5
            row = layout.row()
            row.template_list("STORYBOARD_UL_storyboard_views", "The_List",
                                scene, "sb_camviews", scene, "sb_cvindex", rows=rows)
            col = row.column(align=True)
            col.operator("storyboard.storyboardviews", icon='ADD', text="").action = 'ADD'
            col.operator("storyboard.storyboardviews", icon='REMOVE', text="").action = 'REMOVE'
            col.separator()
            col.menu("STORYBOARD_MT_sbviewsmenu", icon='DOWNARROW_HLT', text="")
            col.separator()
            colb = col.column(align=True)
            colb.operator("storyboard.storyboardviews", icon='TRIA_UP', text="").action = 'UP'
            colb.operator("storyboard.storyboardviews", icon='TRIA_DOWN', text="").action = 'DOWN'
            row = layout.row()
            row.operator("storyboard.storyboardviews", text='Set Active').action = 'ACTIVATE'
            row = layout.row()
            row.operator("storyboard.storyboardviews", icon='TRIA_LEFT', text='Previous').action = 'PREVIOUS'
            row.operator("storyboard.storyboardviews", icon='TRIA_RIGHT', text='Next').action = 'NEXT'


class STORYBOARD_PT_render_settings(Panel):
    """Storyboard sub panel for Scene Render Settings.
    """
    bl_label = " "
    bl_idname = "SCENE_PT_SBrendersettings"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Storyboard'
    bl_options = {'DEFAULT_CLOSED'}    # Panel will be collapsed
    bl_parent_id = 'SCENE_PT_CamStoryboard'   # will be a sub-panel

    def draw_header(self, context):
        layout = self.layout
        row = layout.row()
        # row.label(text="Render Settings", icon='OUTPUT')
        row.label(text="Render Settings", icon='SETTINGS')

    def draw(self, context):
        layout = self.layout
        render = context.scene.render
        storyboard = bpy.context.scene.sb_data
        if storyboard.created:
            row = layout.row()
            row.label(text="Output Dimensions")
            row = layout.row()
            row.prop(storyboard, "cam_rendersettings", expand=True)
            if storyboard.cam_rendersettings == 'SCENE':
                row = layout.row()
                row.alignment = 'RIGHT'
                row.label(text="Resolution X")
                row.prop(render, "resolution_x", text="")
                row = layout.row()
                row.alignment = 'RIGHT'
                row.label(text="Y")
                row.prop(render, "resolution_y", text="")
                row = layout.row()
                row.operator("storyboard.sbcamsave").action = 'SCENE'
            if storyboard.cam_rendersettings == 'OPTONE':
                if not storyboard.scene_res_saved:
                    row = layout.row()
                    row.label(text="Save Scene Resolution First")
                else:
                    row = layout.row()
                    row.alignment = 'RIGHT'
                    row.label(text="Resolution X")
                    row.prop(render, "resolution_x", text="")
                    row = layout.row()
                    row.alignment = 'RIGHT'
                    row.label(text="Y")
                    row.prop(render, "resolution_y", text="")
                    row = layout.row()
                    row.operator("storyboard.sbcamsave", text="Save Option 1 Resolution").action = 'OPTONE'
            if storyboard.cam_rendersettings == 'OPTTWO':
                if not storyboard.scene_res_saved:
                    row = layout.row()
                    row.label(text="Save Scene Resolution First")
                else:
                    row = layout.row()
                    row.alignment = 'RIGHT'
                    row.label(text="Resolution X")
                    row.prop(render, "resolution_x", text="")
                    row = layout.row()
                    row.alignment = 'RIGHT'
                    row.label(text="Y")
                    row.prop(render, "resolution_y", text="")
                    row = layout.row()
                    row.operator("storyboard.sbcamsave", text="Save Option 2 Resolution").action = 'OPTTWO'


class STORYBOARD_UL_outlines(UIList):

    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):

        # add code to decide which icon to use here...
        custom_icon = 'OBJECT_DATA'

        # Make sure code supports all 3 layout types
        if self.layout_type in {'DEFAULT', 'COMPACT'}:
            # split = layout.split(factor=0.18)
            # split.label(text=str(item.frame))
            # split.label(text=item.name, icon=custom_icon)
            layout.label(text=item.name, icon=custom_icon)
        elif self.layout_type in {'GRID'}:
            layout.alignment = 'CENTER'
            layout.label(text=item.name, icon=custom_icon)


class STORYBOARD_PT_layout(Panel):
    """Creates a Panel in the Tool Shelf with the Storyboard panel. 
    Changes layout of the current scene.
    """
    bl_label = " "
    bl_idname = "SCENE_PT_StoryboardLayout"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Storyboard'
    bl_parent_id = 'SCENE_PT_storyboard'   # will be a sub-panel
    bl_options = {'DEFAULT_CLOSED'}    # Panel will be collapsed
    bl_context = "scene"

    def draw_header(self, context):
        layout = self.layout
        row = layout.row()
        row.label(text="Panel Layout", icon='SNAP_VERTEX')

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        storyboard = bpy.context.scene.sb_data
        preferences = bpy.context.preferences.addons[__package__].preferences

        row = layout.row()
        if not storyboard.created:
            row.label(text="Create Storyboard First")
        else:
            row.label(text="Panel Alignment")
            row = layout.row()
            if preferences.bigbuttons:
                row.scale_y = 1.5
            row.operator("storyboard.rearrange")
            row = layout.row()
            row.label(text="Panel Outlines")
            row = layout.row()
            if not (2, 90, 0) > bpy.app.version:
                # row.label(text="Convert Boards to GP")
                # row = layout.row()
                row.operator("boards.conversion",
                             text="Convert Board to GP").action = 'VER290'
                row = layout.row()
            elif not (2, 83, 0) > bpy.app.version:
                # row.label(text="Convert Boards to GP")
                # row = layout.row()
                row.operator("boards.conversion",
                             text="Convert Board to GP").action = 'VER283'
                row = layout.row()
            else:
                row = layout.row()

            if preferences.seefuture:
                row = layout.row()
                row.template_list("STORYBOARD_UL_outlines", "The_List",
                                  scene, "sb_borders", scene, "sb_bindex")
                row = layout.row()
                col = row.column(align=True)
                # row = col.row(align=True)
                # row.operator("sb_borders.make_outlines")
                row = col.row(align=True)
                row.operator("sb_borders.add_outline")
                # row.operator("sb_borders.select_items", icon="GROUP",
                #              text="Select all Items").select_all = True
                # row = col.row(align=True)
                # row.operator("sb_borders.delete_all", icon="X")
                row = col.row(align=True)
                row.operator("sb_borders.delete_outline", icon="X")


class STORYBOARD_PT_copy_move(Panel):
    """ Copy objects from one panel to another """
    bl_label = " "
    bl_idname = "SCENE_PT_StoryboardLayoutCopy"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Storyboard'
    bl_parent_id = 'SCENE_PT_StoryboardLayout'   # will be a sub-panel
    # bl_options = {'DEFAULT_CLOSED'}    # Panel will be collapsed

    def draw_header(self, context):
        layout = self.layout
        row = layout.row()
        row.label(text="Copy-Move Objects", icon='DUPLICATE')

    def draw(self, context):

        layout = self.layout
        scene = context.scene
        obj = bpy.context.active_object
        storyboard = bpy.context.scene.sb_data
        shot_list = bpy.data.collections['Storyboard_Cameras']
        if storyboard.created:
            row = layout.row(align=True)
            row.prop_search(scene, "panelCopyObj", bpy.data, "grease_pencils")
            row = layout.row(align=True)
            # row.prop_search(scene, "panelPasteCam", scene, "objects")
            row.prop_search(scene, "panelPasteCam", shot_list, "objects")
            row = layout.row()
            row.enabled = bool(scene.panelCopyObj and scene.panelPasteCam)
            row.operator('storyboard.copytopanel', text='Copy GP Obj to Shot')
            row = layout.row()
            row.enabled = bool(scene.panelCopyObj and scene.panelPasteCam)
            # row.enabled = False
            row.operator('storyboard.movetopanel', text='Move GP Obj to Shot')


class STORYBOARD_PT_swap_shots(Panel):
    """ Swap all objects from one panel to another """
    bl_label = " "
    bl_idname = "SCENE_PT_StoryboardLayoutSwap"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Storyboard'
    bl_parent_id = 'SCENE_PT_StoryboardLayout'   # will be a sub-panel
    bl_options = {'DEFAULT_CLOSED'}    # Panel will be collapsed

    def draw_header(self, context):
        layout = self.layout
        row = layout.row()
        row.label(text="Swap Shot Elements", icon='FILE_REFRESH')

    def draw(self, context):

        layout = self.layout
        scene = context.scene
        obj = bpy.context.active_object
        storyboard = bpy.context.scene.sb_data
        preferences = bpy.context.preferences.addons[__package__].preferences
        shot_list = bpy.data.collections['Storyboard_Cameras']
        if storyboard.created:
            # if storyboard.created and preferences.seefuture:
            row = layout.row(align=True)
            row.prop_search(scene, "panelSwapACam", shot_list, "objects")
            row = layout.row(align=True)
            row.prop_search(scene, "panelSwapBCam", shot_list, "objects")
            row = layout.row()
            shots_selected = bool(scene.panelSwapACam and scene.panelSwapBCam)
            shots_unique = not bool(scene.panelSwapACam == scene.panelSwapBCam)
            row.enabled = bool(shots_selected and shots_unique)
            # row.enabled = False
            row.operator('boards.swapshot', text='Swap Shots')


class STORYBOARD_PT_addition(Panel):
    """Creates a Panel in the Tool Shelf with the Storyboard panel. 
    Add panels to the current scene.
    """
    bl_label = " "
    bl_idname = "SCENE_PT_StoryboardAdd"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Storyboard'
    bl_parent_id = 'SCENE_PT_storyboard'   # will be a sub-panel
    bl_options = {'DEFAULT_CLOSED'}    # Panel will be collapsed

    def draw_header(self, context):
        layout = self.layout
        row = layout.row()
        row.label(text="Panel Addition", icon='PLUS')

    def draw(self, context):
        # layout = self.layout
        scene = context.scene
        storyboard = bpy.context.scene.sb_data
        preferences = bpy.context.preferences.addons[__package__].preferences

        layout = self.layout
        if not storyboard.created:
            row = layout.row()
            row.label(text="Create Storyboard First")
        else:
            row = layout.row()
            row.prop(storyboard, 'fast_draw')
            # split = layout.split(factor=0.4, align=True)
            # col = split.column()
            # col.prop(storyboard, 'fast_draw')
            # col = split.column()
            # col.active = storyboard.fast_draw
            # col.active = False
            # row = layout.row()
            # row.label(text=storyboard.fastdraw_layer)
            # row.prop(storyboard, 'fastdraw_layer', text="Layer")
            row = layout.row()
            row.label(text="Automatic Placement")
            if preferences.seefuture:
                row = layout.row()
                if preferences.bigbuttons:
                    row.scale_y = 1.5
                row.enabled = False
                row.operator('boards.append', text="Insert Shot")
            row = layout.row()
            if preferences.bigbuttons:
                row.scale_y = 1.5
            row.operator('boards.append', text="Add Shot")
            row = layout.row()
            row.label(text="Manual Placement")
            row = layout.row()
            row.operator('boards.addition', text="Add Board, Cam, Marker")


class STORYBOARD_PT_elements(Panel):
    """Creates a Panel in the Tool Shelf.
    This is to work with objects related to a single shot.
    """
    bl_label = " "
    bl_idname = "SCENE_PT_Board"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Storyboard'
    bl_parent_id = 'SCENE_PT_storyboard'   # will be a sub-panel
    bl_options = {'DEFAULT_CLOSED'}    # Panel will be collapsed

    def draw_header(self, context):
        layout = self.layout
        activecam_name = ""
        cam = bpy.context.scene.camera
        if (cam and cam.type == 'CAMERA'):
            activecam_name = cam.name + " -"
        labtext = activecam_name + " Objects"
        row = layout.row()
        # row.label(text=labtext)
        row.label(text="Panel Elements", icon='SNAP_FACE')
        # row.label(text=labtext, icon='IMAGE_REFERENCE')

    def draw(self, context):
        yloc = 0.0
        layout = self.layout
        scene = context.scene
        storyboard = bpy.context.scene.sb_data
        preferences = bpy.context.preferences.addons[__package__].preferences
        activecam_name = ""
        activeobj_name = ""
        focus = False
        fpoint = None
        cam = bpy.context.scene.camera
        for o in cam.data.sb_objects:
            if o.focus:
                focus = True
                fpoint = o.obj.location[1]
                focal_obj = o.obj
                break
        obj = bpy.context.active_object
        if not obj:
            activeobj_name = "None"
        else:
            activeobj_name = obj.name

        if (cam and cam.type == 'CAMERA'):
            activecam_name = cam.name

        if storyboard.created:
            # row = layout.row()
            # row.operator('boards.cursortopanel', icon='CURSOR')
            if focus:
                row = layout.row()
                row.prop(focal_obj, "location", index=1, text="Focal Point")
            else:
                row = layout.row()
                row.operator('boards.addfocus', text="Add Focus Object", icon='OBJECT_DATAMODE')
            row = layout.row()
            row.operator('boards.addtext', icon='OUTLINER_OB_FONT')
        row = layout.row()
        row.operator('gpencil.addbasic', text="Add Basic GPencil", icon='OUTLINER_OB_GREASEPENCIL')

        # row = layout.row()
        # row.use_property_split = True
        # fobj = context.object
        # if fobj:
        #     row.prop(fobj, "location")

        # row = layout.row()
        # # row.scale_y = 1.5
        # # row.label(text="Active Object: " + activeobj_name)
        # row.label(text="Active Object:")

        # row = layout.row()
        # row.alignment = 'CENTER'
        # row.label(text=activeobj_name)

        row = layout.row()
        cola = row.column()
        rowa = cola.row()
        rowa.label(text="Active Object: ")
        rowa.label(text=activeobj_name)
        colb = row.column()
        colb.alignment = 'RIGHT'
        if storyboard.created:
            colb.operator('boards.find', text="", icon='CENTER_ONLY')

        row = layout.row()
        cola = row.column()
        rowa = cola.row()
        rowa.label(text="Active Camera: ")
        rowa.label(text=activecam_name)
        colb = row.column()
        colb.alignment = 'RIGHT'
        if storyboard.created:
            colb.operator('boards.cursortopanel', text="", icon='CURSOR')

        if storyboard.created:
            # row = layout.row(align=True)
            # row.prop_search(scene, "panelCopyObj", scene, "objects")
            # row = layout.row(align=True)
            # # row.active = bool(obj and obj.type == 'CAMERA')
            # row.prop_search(scene, "panelPasteCam", scene, "objects")
            row = layout.row()
            if preferences.bigbuttons:
                row.scale_y = 1.5
            txtcam = "Assign to: " + activecam_name
            row.operator('boards.addelement', text=txtcam, icon='CHECKMARK')
            # row.operator('boards.find', text="Jump to Shot")


class STORYBOARD_PT_objects(Panel):
    """Creates a Panel in the Tool Shelf with the Storyboard panel. 
    Objects specific to current shot.
    """
    bl_label = " "
    bl_idname = "SCENE_PT_Subboard"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Storyboard'
    # bl_options = {'DEFAULT_CLOSED'}    # Panel will be collapsed
    bl_parent_id = 'SCENE_PT_Board'   # will be a sub-panel

    def draw_header(self, context):
        layout = self.layout
        row = layout.row()
        row.label(text="Objects", icon='GROUP')

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        storyboard = bpy.context.scene.sb_data
        preferences = bpy.context.preferences.addons[__package__].preferences
        if storyboard.created:
            row = layout.row()
            if preferences.bigbuttons:
                row.scale_y = 1.5
            row.operator('boards.pickallelements', text="Select All Objects")

        activecam_name = ""
        cam = bpy.context.scene.camera
        if (cam and cam.type == 'CAMERA'):
            activecam_name = cam.name
        labtext = "List of Objects - " + activecam_name
        layout.label(text=labtext)

        obj = bpy.context.scene.camera
        if (obj and obj.type == 'CAMERA'):
            for o in reversed(obj.data.sb_objects):
                if o.obj and o.obj.type == 'GPENCIL':
                    img = 'OUTLINER_OB_GREASEPENCIL'
                elif o.obj and "Focal" in o.obj.name:
                    img = 'OBJECT_DATAMODE'
                elif o.obj and "board" in o.obj.name:
                    img = 'MESH_PLANE'
                elif o.obj and o.obj.type == 'EMPTY':
                    img = 'OUTLINER_OB_EMPTY'
                elif o.obj and o.obj.type == 'MESH':
                    img = 'OUTLINER_OB_MESH'
                elif o.obj and o.obj.type == 'FONT':
                    img = 'OUTLINER_OB_FONT'
                else:
                    img = "BLANK1"
                row = layout.row(align=True)
                row.context_pointer_set("object", o)
                row.operator("boards.pickelement",
                             text=o.obj.name, icon=img)
                row.operator("boards.unlinkelement",
                             text='', icon='REMOVE')
        else:
            layout.label(text="No cameras")


class STORYBOARD_UL_perspective(UIList):

    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):

        # add code to decide which icon to use here...
        custom_icon = 'SORTBYEXT'

        # Make sure code supports all 3 layout types
        if self.layout_type in {'DEFAULT', 'COMPACT'}:
            # layout.label(text=item.name, icon=custom_icon)
            # vlayer = bpy.context.scene.view_layers['View Layer']
            # objview = vlayer.layer_collection.children['Storyboard']
            objview = bpy.data.objects[item.gpname]
            # split = layout.split(factor=0.3)
            # split.label(text=item.name, icon=custom_icon)
            # split.label(text=item.gpname)
            # split.prop(objview, "hide_viewport", text="",
            #            emboss=False, icon='HIDE_OFF')
            row = layout.row()
            # row.label(text=item.name, icon=custom_icon)
            row.label(text=item.gpname, icon=custom_icon)
            # row = split.row()
            row.alignment = 'RIGHT'
            row.prop(objview, "hide_viewport", text="",
                     emboss=False, icon='HIDE_OFF')
        elif self.layout_type in {'GRID'}:
            layout.alignment = 'CENTER'
            layout.label(text="", icon=custom_icon)


class STORYBOARD_PT_guides(Panel):
    """Storyboard sub panel for guides, grids and rulers.
    """
    bl_label = " "
    bl_idname = "SCENE_PT_Sbguides"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Storyboard'
    bl_options = {'DEFAULT_CLOSED'}    # Panel will be collapsed
    bl_parent_id = 'SCENE_PT_Board'   # will be a sub-panel

    def draw_header(self, context):
        layout = self.layout
        row = layout.row()
        row.label(text="Guides", icon='GRID')

    def draw(self, context):
        layout = self.layout
        scene = bpy.context.scene
        gp_angler = False
        gp_guide = scene.tool_settings.gpencil_sculpt.guide
        if gp_guide.type == 'CIRCULAR':
            guide_icon = 'MESH_CIRCLE'
        if gp_guide.type == 'RADIAL':
            guide_icon = 'SORTBYEXT'
        if gp_guide.type == 'PARALLEL':
            guide_icon = 'ALIGN_JUSTIFY'
        if gp_guide.type == 'GRID':
            guide_icon = 'MESH_GRID'
        if gp_guide.type == 'ISO':
            guide_icon = 'MOD_LATTICE'
        sbperidx = scene.sb_pindex
        settings = scene.tool_settings.gpencil_sculpt.guide
        storyboard = bpy.context.scene.sb_data
        preferences = bpy.context.preferences.addons[__package__].preferences
        if storyboard.created:
            row = layout.row()
            cola = row.column(align=True)
            cola.prop(settings, "use_guide")
            colb = row.column(align=True)
            row = colb.row()
            row.alignment = 'RIGHT'
            row.label(text="Type:")
            row.label(text="", icon=guide_icon)
            row = layout.row()
            row.prop(gp_guide, "type", expand=True)
            if (gp_guide.type == 'RADIAL') or (gp_guide.type == 'CIRCULAR'):
                row = layout.row()
                row.label(text="Perspective Points")
                rows = 3
                row = layout.row()
                row.template_list("STORYBOARD_UL_perspective", "The_List",
                                  scene, "sb_ppoints", scene, "sb_pindex", rows=rows)
                col = row.column(align=True)
                col.operator("sboard.persplist_add", icon='ADD', text="")
                # col.operator("sboard.persplist_action",
                #              icon='ADD', text="").action = 'ADD'
                col.operator("sboard.persplist_action",
                             icon='REMOVE', text="").action = 'REMOVE'
                # col.operator("sb_borders.delete_outline", icon='REMOVE', text="")
                # row = layout.row()
                # row.operator("sb_borders.add_outline",
                #              icon='GRID', text="Use Guide")
                row = layout.row()
                # row.prop(settings, "use_guide", text="", icon='GRID')
                row.operator("sboard.guidepersp", text='Set Reference')
                row.operator("sboard.guideinactive", text='ALL Inactive')
                # row = layout.row()
                # row.operator("sboard.guidegrid", text='Grid')
                refobj = ""
                if gp_guide.reference_point == 'OBJECT':
                    if gp_guide.reference_object:
                        refobj = gp_guide.reference_object.name
                if gp_guide.reference_point == 'CURSOR':
                    refobj = "CURSOR"
                # row = layout.row()
                split = layout.split(factor=0.15)
                split.label(text="Ref:")
                # row = layout.row()
                split.label(text=refobj)
            # row = layout.row()
            # row.alignment = 'LEFT'
            # # row.prop(settings, "use_guide", text="", icon='GRID')
            # row.label(text="Guide Type:")
            # row.label(text="", icon=guide_icon)
            # # row.label(text="", icon='MESH_CIRCLE')
            # # row.label(text="", icon='SORTBYEXT')
            # row = layout.row()
            # row.prop(gp_guide, "type", expand=True)
            # if preferences.seefuture:
            if (gp_guide.type == 'PARALLEL') or (gp_guide.type == 'ISO'):
                row = layout.row()
                row.label(text="Angle")
                try:
                    if bpy.data.objects['Angle Guide']:
                        gp_angler = True
                        row = layout.row()
                        row.label(text="", icon='DRIVER_ROTATIONAL_DIFFERENCE')
                        row.prop(bpy.context.scene,
                                 "angle_guide", text="Guide")
                        obangle = bpy.data.objects['Angle Guide']
                        row = layout.row()
                        row.label(text="", icon='ARROW_LEFTRIGHT')
                        row.prop(obangle, "location",
                                 index=0, text="Horizontal")
                        row = layout.row()
                        row.label(text="", icon='SORT_DESC')
                        row.prop(obangle, "location",
                                 index=2, text="Vertical")
                except KeyError:
                    pass
                if not gp_angler:
                    row = layout.row()
                    # row.enabled = False
                    row.operator("gpencil.angleguide", text='Add Angle Guide')
                else:
                    # Add more features here:
                    # - Select/Deselect
                    # - View/Hide
                    # - Active/Inactive material
                    row = layout.row()
                    # row.label(text="", icon='RESTRICT_SELECT_OFF')
                    # row.label(text="", icon='HIDE_OFF')
            # row = layout.row()
            # row.label(text="Active Color ")
            # row.prop(
            #     bpy.context.scene, 'sb_pactive_color', text="")
            # row = layout.row()
            # row.label(text="Inactive Color ")
            # row.prop(
            #     bpy.context.scene, 'sb_pinactive_color', text="")

        # rows = 2
        # row = layout.row()
        # row.template_list("STORYBOARD_UL_frameitems", "", storyboard,
        #                   "sbframes", scene, "sbframe_idx", rows=rows)

        # col = row.column(align=True)
        # col.operator("sbframes.framelist_action",
        #              icon='ADD', text="").action = 'ADD'
        # col.operator("sbframes.framelist_action", icon='REMOVE',
        #              text="").action = 'REMOVE'
        # col.separator()
        # col.operator("sbframes.framelist_action",
        #              icon='TRIA_UP', text="").action = 'UP'
        # col.operator("sbframes.framelist_action", icon='TRIA_DOWN',
        #              text="").action = 'DOWN'

        # row = layout.row()
        # col = row.column(align=True)
        # row = col.row(align=True)
        # row.operator("sbframes.print_items", icon="LINENUMBERS_ON") #LINENUMBERS_OFF, ANIM
        # row = col.row(align=True)
        # row.operator("sbframes.select_items", icon="VIEW3D", text="Select Item")
        # row.operator("sbframes.select_items", icon="GROUP", text="Select all Items").select_all = True
        # row = col.row(align=True)
        # row.operator("sbframes.clear_list", icon="X")
        # row.operator("sbframes.remove_duplicates", icon="GHOST_ENABLED")

        # activecam_name = ""
        # cam = bpy.context.scene.camera
        # if (cam and cam.type == 'CAMERA'):
        #     activecam_name = cam.name
        # labtext = "List of Guides - " + activecam_name
        # layout.label(text=labtext)

        # obj = bpy.context.scene.camera
        # if (obj and obj.type == 'CAMERA'):
        #     # for o in obj.data.sb_objects:
        #     for o in reversed(obj.data.sb_objects):
        #         if o.obj and o.obj.type == 'GPENCIL':
        #             img = 'OUTLINER_OB_GREASEPENCIL'
        #         elif o.obj and "Focal" in o.obj.name:
        #             img = 'OBJECT_DATAMODE'
        #         elif o.obj and "board" in o.obj.name:
        #             img = 'MESH_PLANE'
        #         elif o.obj and o.obj.type == 'MESH':
        #             img = 'OUTLINER_OB_MESH'
        #         else:
        #             img = "BLANK1"
        #             #img = 'CHECKMARK'
        #         row = layout.row(align=True)
        #         row.context_pointer_set("object", o)
        #         row.operator("boards.pickelement",
        #                      text=o.obj.name, icon=img)
        #         row.operator("boards.unlinkelement",
        #                      text='', icon='REMOVE')
        # else:
        #     layout.label(text="No cameras")


class STORYBOARD_PT_guide_settings(Panel):
    """Storyboard sub panel for guides, grids and rulers.
    """
    bl_label = " "
    bl_idname = "SCENE_PT_Sbguidesettings"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Storyboard'
    bl_options = {'DEFAULT_CLOSED'}    # Panel will be collapsed
    bl_parent_id = 'SCENE_PT_Sbguides'   # will be a sub-panel

    def draw_header(self, context):
        layout = self.layout
        row = layout.row()
        row.label(text="Guide Settings", icon='SETTINGS')

    def draw(self, context):
        layout = self.layout
        row = layout.row()
        row.label(text="Active Color ")
        row.prop(
            bpy.context.scene, 'sb_pactive_color', text="")
        row = layout.row()
        row.label(text="Inactive Color ")
        row.prop(
            bpy.context.scene, 'sb_pinactive_color', text="")
        row = layout.row()
        row.prop(bpy.context.scene, 'sb_pline', text="Line Thickness")


classes = (
    STORYBOARD_PT_main,
    STORYBOARD_PT_cameras,
    STORYBOARD_MT_sbviewsmenu,
    STORYBOARD_UL_storyboard_views,
    STORYBOARD_PT_cam_storyboard,
    STORYBOARD_PT_render_settings,
    STORYBOARD_UL_outlines,
    STORYBOARD_PT_layout,
    STORYBOARD_PT_copy_move,
    STORYBOARD_PT_swap_shots,
    STORYBOARD_PT_addition,
    STORYBOARD_PT_elements,
    STORYBOARD_PT_objects,
    STORYBOARD_UL_perspective,
    STORYBOARD_PT_guides,
    STORYBOARD_PT_guide_settings,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in classes:
        bpy.utils.unregister_class(cls)
