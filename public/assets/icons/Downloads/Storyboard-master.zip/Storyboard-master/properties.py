import bpy
from bpy.types import PropertyGroup, AddonPreferences
from bpy.props import (
    BoolProperty,
    CollectionProperty,
    IntProperty,
    FloatProperty,
    PointerProperty,
    StringProperty,
    EnumProperty,
    FloatVectorProperty
)


def update_fave_layer(self, context, origin):
    if (origin == "fav2") and (self.gplayer_fav2_fave == self.gplayer_fav4_fave):
        self.gplayer_fav4_fave = not self.gplayer_fav4_fave
    if (origin == "fav4") and (self.gplayer_fav2_fave == self.gplayer_fav4_fave):
        self.gplayer_fav2_fave = not self.gplayer_fav2_fave


def update_scene_res(self, context):
    scn = bpy.context.scene
    storyboard = bpy.context.scene.sb_data
    if (self.cam_rendersettings == "SCENE"):
        if storyboard.scene_res_saved:
            scn.render.resolution_x = storyboard.scene_res_x
            scn.render.resolution_y = storyboard.scene_res_y
    if (self.cam_rendersettings == "OPTONE"):
        if storyboard.scene_res_saved:
            scn.render.resolution_x = storyboard.optone_res_x
            scn.render.resolution_y = storyboard.optone_res_y
    if (self.cam_rendersettings == "OPTTWO"):
        if storyboard.scene_res_saved:
            scn.render.resolution_x = storyboard.opttwo_res_x
            scn.render.resolution_y = storyboard.opttwo_res_y
    return


class StoryboardAddonPreferences(AddonPreferences):
    """Storyboard Addon Preferences"""
    bl_idname = __package__

    quickstart: BoolProperty(
        name="Quick Start Creation",
        description="Create storyboard with no pop-up window",
        default=False
    )
    boardstyle: EnumProperty(
        name="Camera List",
        description="Create storyboard in a grid or strip",
        items=[
            ('GRID', "Grid",
             "Grid is recommended for thumbnail renders"),
            ('STRIP', "Horizontal Strip",
             "Strip is recommended for workspace viewing"),
        ],
        default='GRID'
    )
    main_camera_names: StringProperty(
        name='Camera Names',
        description="Default name for cameras created ex: Shot",
        default="Shot"
    )
    columns: IntProperty(
        name='Storyboard Columns',
        default=4,
        min=1,
    )
    rows: IntProperty(
        name='Storyboard Rows',
        default=3,
        min=1,
    )
    time_gap: IntProperty(
        name='Storyboard Time Gap',
        description="Number of frames between camera bound markers",
        default=20,
        min=1,
    )
    bigbuttons: BoolProperty(
        name="Expand Buttons",
        description="Expand the size of important buttons",
        default=True
    )
    seefuture: BoolProperty(
        name="See Future Features",
        description="Show inactive parts of the interface for features coming next",
        default=False
    )
    gplayer_fav_bool: BoolProperty(
        name="Activate Grease Pencil Layer",
        description="Create a Grease Pencil layer with this name",
        default=False
    )
    gplayer_fav_name: StringProperty(
        name='Grease Pencil Layer Name',
        default="Custom Foreground"
    )
    gplayer_fav1_bool: BoolProperty(
        name="Activate Grease Pencil Layer",
        description="Create a Grease Pencil layer with this name",
        default=True
    )
    gplayer_fav1_name: StringProperty(
        name='Grease Pencil Layer Name',
        default="Character Clean"
    )
    gplayer_fav2_bool: BoolProperty(
        name="Activate Grease Pencil Layer",
        description="Create a Grease Pencil layer with this name",
        default=True
    )
    gplayer_fav2_name: StringProperty(
        name='Grease Pencil Layer Name',
        default="Character Rough"
    )
    gplayer_fav2_fave: BoolProperty(
        name="Favorite Grease Pencil Layer",
        description="Choose this Grease Pencil layer first",
        # update=update_fave_layer,
        update=lambda a, b: update_fave_layer(a, b, "fav2"),
        default=True
    )
    gplayer_fav3_bool: BoolProperty(
        name="Activate Grease Pencil Layer",
        description="Create a Grease Pencil layer with this name",
        default=True
    )
    gplayer_fav3_name: StringProperty(
        name='Grease Pencil Layer Name',
        default="Background Clean"
    )
    gplayer_fav4_bool: BoolProperty(
        name="Activate Grease Pencil Layer",
        description="Create a Grease Pencil layer with this name",
        default=True
    )
    gplayer_fav4_name: StringProperty(
        name='Grease Pencil Layer Name',
        default="Background Rough"
    )
    gplayer_fav4_fave: BoolProperty(
        name="Favorite Grease Pencil Layer",
        description="Choose this Grease Pencil layer first",
        # update=update_fave_layer,
        update=lambda a, b: update_fave_layer(a, b, "fav4"),
        default=False
    )
    gplayer_fav5_bool: BoolProperty(
        name="Activate Grease Pencil Layer",
        description="Create a Grease Pencil layer with this name",
        default=False
    )
    gplayer_fav5_name: StringProperty(
        name='Grease Pencil Layer Name',
        default="Custom Background"
    )

    # Black Material Properties
    mat_blk_bool: BoolProperty(
        name="Activate Grease Pencil Material",
        description="Activate the black material to be used in the scene",
        default=True
    )

    # Grey Material Properties
    mat_gry_bool: BoolProperty(
        name="Activate Grease Pencil Material",
        description="Activate the grey materials to be used in the scene",
        default=True
    )

    # White Material Properties
    mat_wht_bool: BoolProperty(
        name="Activate Grease Pencil Material",
        description="Activate the white material to be used in the scene",
        default=True
    )

    # CornFlowerBlue Material Properties
    mat_fav_bool: BoolProperty(
        name="Activate Grease Pencil Material",
        description="Activate the material to be used in the scene",
        default=False
    )
    mat_fav_name: StringProperty(
        name='Grease Pencil Material Name',
        default="CornFlowerBlue"
    )
    mat_fav_stkbool: BoolProperty(
        name="Activate Grease Pencil Material Stroke",
        description="Activate the stroke color",
        default=True
    )
    mat_fav_stkcolor: FloatVectorProperty(
        name='Grease Pencil Material Stroke Color',
        subtype='COLOR',
        default=(0.127, 0.301, 0.847, 0.8),  # CornFlowerBlue
        size=4,
        min=0, max=1,
    )
    mat_fav_fillbool: BoolProperty(
        name="Activate Grease Pencil Material Fill",
        description="Activate the fill color",
        default=False
    )
    mat_fav_fillcolor: FloatVectorProperty(
        name='Grease Pencil Material Fill Color',
        subtype='COLOR',
        #        default=(0.127, 0.301, 0.847, 0.8),
        size=4,
        min=0, max=1,
    )

    # NonReproBlue Material Properties
    mat_fav1_bool: BoolProperty(
        name="Activate Grease Pencil Material",
        description="Activate the material to be used in the scene",
        default=False
    )
    mat_fav1_name: StringProperty(
        name='Grease Pencil Material 1 Name',
        default="NonReproBlue"
    )
    mat_fav1_stkbool: BoolProperty(
        name="Activate Grease Pencil Material Stroke",
        description="Activate the stroke color",
        default=True
    )
    mat_fav1_stkcolor: FloatVectorProperty(
        name='Grease Pencil Material Stroke Color',
        subtype='COLOR',
        # default=(0.05, 0.08, 0.3)
        default=(0.371, 0.723, 0.847, 1.0),   # NonReproBlue
        size=4,
        min=0, max=1,
    )
    mat_fav1_fillbool: BoolProperty(
        name="Activate Grease Pencil Material Fill",
        description="Activate the fill color",
        default=False
    )
    mat_fav1_fillcolor: FloatVectorProperty(
        name='Grease Pencil Material Fill Color',
        subtype='COLOR',
        #        default=(0.127, 0.301, 0.847, 0.8),
        size=4,
        min=0, max=1,
    )

    # NonPhotoRed Material Properties
    mat_fav2_bool: BoolProperty(
        name="Activate Grease Pencil Material",
        description="Activate the material to be used in the scene",
        default=False
    )
    mat_fav2_name: StringProperty(
        name='Grease Pencil Material 2 Name',
        default="NonPhotoRed"
    )
    mat_fav2_stkbool: BoolProperty(
        name="Activate Grease Pencil Material Stroke",
        description="Activate the stroke color",
        default=True
    )
    mat_fav2_stkcolor: FloatVectorProperty(
        name='Grease Pencil Material Stroke Color',
        subtype='COLOR',
        default=(0.847, 0.178, 0.178, 1.0),   # NonPhotoRed
        size=4,
        min=0, max=1,
    )
    mat_fav2_fillbool: BoolProperty(
        name="Activate Grease Pencil Material Fill",
        description="Activate the fill color",
        default=False
    )
    mat_fav2_fillcolor: FloatVectorProperty(
        name='Grease Pencil Material Fill Color',
        subtype='COLOR',
        #        default=(0.127, 0.301, 0.847, 0.8),
        size=4,
        min=0, max=1,
    )

    # Custom Material Properties
    mat_fav3_bool: BoolProperty(
        name="Activate Grease Pencil Material",
        description="Activate the material to be used in the scene",
        default=False
    )
    mat_fav3_name: StringProperty(
        name='Grease Pencil Material Name',
        default="CustomMaterial"
    )
    mat_fav3_stkbool: BoolProperty(
        name="Activate Grease Pencil Material Stroke",
        description="Activate the stroke color",
        default=True
    )
    mat_fav3_stkcolor: FloatVectorProperty(
        name='Grease Pencil Material Stroke Color',
        subtype='COLOR',
        default=(1.0, 0.0, 1.0, 0.8),   # Custom
        size=4,
        min=0, max=1,
    )
    mat_fav3_fillbool: BoolProperty(
        name="Activate Grease Pencil Material Fill",
        description="Activate the fill color",
        default=False
    )
    mat_fav3_fillcolor: FloatVectorProperty(
        name='Grease Pencil Material Fill Color',
        subtype='COLOR',
        size=4,
        min=0, max=1,
    )

    def draw(self, context):
        layout = self.layout
        row = layout.row()
        row.prop(self, 'seefuture')
        row.prop(self, 'bigbuttons')
        # if self.seefuture:
        #     row = layout.row()
        #     row.enabled = False
        #     row.prop(self, 'main_camera_names')
        # Creation
        create_box = layout.box()
        create_box.row().label(text="Storyboard Creation:")
        row = create_box.row()
        row.prop(self, 'main_camera_names')
        row = create_box.row()
        row.label(text="Storyboard Layout:")
        row.prop(self, 'boardstyle', expand=True)
        row = create_box.row()
        grid = "Storyboard Columns"
        if self.boardstyle == 'STRIP':
            grid = "Storyboard Panels"
        row.prop(self, 'columns', text=grid)
        if grid == "Storyboard Columns":
            row.prop(self, 'rows')
        row = create_box.row()
        row.prop(self, 'quickstart')

        # Layers
        layer_box = layout.box()
        layer_box.row().label(text="Grease Pencil Custom Layer Names:")
        split = layer_box.split(factor=0.05)
        col_1 = split.column()
        col_2 = split.column()
        row = col_1.row()
        row.prop(self, 'gplayer_fav_bool', text="")
        row = col_2.row()
        row.enabled = self.gplayer_fav_bool
        row.prop(self, 'gplayer_fav_name', text="")
        row = col_1.row()
        row.prop(self, 'gplayer_fav1_bool', text="")
        row = col_2.row()
        row.enabled = self.gplayer_fav1_bool
        row.prop(self, 'gplayer_fav1_name', text="")
        row = col_1.row()
        row.prop(self, 'gplayer_fav2_bool', text="")
        row = col_2.row()
        row.enabled = self.gplayer_fav2_bool
        row.prop(self, 'gplayer_fav2_name', text="")
        # test of favorite layer
        if self.gplayer_fav2_fave:
            icon_fave2 = 'FUND'
        else:
            icon_fave2 = 'HEART'
        row.prop(self, 'gplayer_fav2_fave', text="", icon=icon_fave2)
        row = col_1.row()
        row.prop(self, 'gplayer_fav3_bool', text="")
        row = col_2.row()
        row.enabled = self.gplayer_fav3_bool
        row.prop(self, 'gplayer_fav3_name', text="")
        row = col_1.row()
        row.prop(self, 'gplayer_fav4_bool', text="")
        row = col_2.row()
        row.enabled = self.gplayer_fav4_bool
        row.prop(self, 'gplayer_fav4_name', text="")
        if self.gplayer_fav4_fave:
            icon_fave4 = 'FUND'
        else:
            icon_fave4 = 'HEART'
        row.prop(self, 'gplayer_fav4_fave', text="", icon=icon_fave4)
        row = col_1.row()
        row.prop(self, 'gplayer_fav5_bool', text="")
        row = col_2.row()
        row.enabled = self.gplayer_fav5_bool
        row.prop(self, 'gplayer_fav5_name', text="")

        # Materials
        mat_box = layout.box()
        mat_box.row().label(text="Grease Pencil Custom Materials:")
        row = mat_box.row()
        row.prop(self, 'mat_blk_bool', text="Black")
        row.prop(self, 'mat_gry_bool', text="Greys")
        row.prop(self, 'mat_wht_bool', text="White")

        # CornFlowerBlue
        splitm = mat_box.split(factor=0.05)
        col_a = splitm.column()
        col_b = splitm.column()
        col_a.prop(self, 'mat_fav_bool', text="")
        if not self.mat_fav_bool:
            split = col_b.split(factor=0.65)
            col_1 = split.column()
            col_2 = split.column()
            row = col_1.row()
            row.enabled = self.mat_fav_bool
            row.prop(self, 'mat_fav_name', text="")
            row = col_2.row()
            row.enabled = self.mat_fav_bool
            row.prop(self, 'mat_fav_stkcolor', text="")
            row.prop(self, 'mat_fav_fillcolor', text="")
        else:
            row = col_b.row()
            row.prop(self, 'mat_fav_name', text="")
            row = mat_box.row()
            row.label(text=" ")
            row.enabled = self.mat_fav_bool
            row.prop(self, 'mat_fav_stkbool', text="Stroke")
            row.prop(self, 'mat_fav_stkcolor', text="")
            row = mat_box.row()
            row.label(text=" ")
            row.prop(self, 'mat_fav_fillbool', text="Fill")
            row.prop(self, 'mat_fav_fillcolor', text="")

        # NonReproBlue
        splitm = mat_box.split(factor=0.05)
        col_a = splitm.column()
        col_b = splitm.column()
        col_a.prop(self, 'mat_fav1_bool', text="")
        if not self.mat_fav1_bool:
            split = col_b.split(factor=0.65)
            col_1 = split.column()
            col_2 = split.column()
            row = col_1.row()
            row.enabled = self.mat_fav1_bool
            row.prop(self, 'mat_fav1_name', text="")
            row = col_2.row()
            row.enabled = self.mat_fav1_bool
            row.prop(self, 'mat_fav1_stkcolor', text="")
            row.prop(self, 'mat_fav1_fillcolor', text="")
        else:
            row = col_b.row()
            row.prop(self, 'mat_fav1_name', text="")
            row = mat_box.row()
            row.label(text=" ")
            row.enabled = self.mat_fav1_bool
            row.prop(self, 'mat_fav1_stkbool', text="Stroke")
            row.prop(self, 'mat_fav1_stkcolor', text="")
            row = mat_box.row()
            row.label(text=" ")
            row.prop(self, 'mat_fav1_fillbool', text="Fill")
            row.prop(self, 'mat_fav1_fillcolor', text="")

        # NonPhotoRed
        splitm = mat_box.split(factor=0.05)
        col_a = splitm.column()
        col_b = splitm.column()
        col_a.prop(self, 'mat_fav2_bool', text="")
        if not self.mat_fav2_bool:
            split = col_b.split(factor=0.65)
            col_1 = split.column()
            col_2 = split.column()
            row = col_1.row()
            row.enabled = self.mat_fav2_bool
            row.prop(self, 'mat_fav2_name', text="")
            row = col_2.row()
            row.enabled = self.mat_fav2_bool
            row.prop(self, 'mat_fav2_stkcolor', text="")
            row.prop(self, 'mat_fav2_fillcolor', text="")
        else:
            row = col_b.row()
            row.prop(self, 'mat_fav2_name', text="")
            row = mat_box.row()
            row.label(text=" ")
            row.prop(self, 'mat_fav2_stkbool', text="Stroke")
            row.prop(self, 'mat_fav2_stkcolor', text="")
            row = mat_box.row()
            row.label(text=" ")
            row.prop(self, 'mat_fav2_fillbool', text="Fill")
            row.prop(self, 'mat_fav2_fillcolor', text="")

        # Custom Material
        splitm = mat_box.split(factor=0.05)
        col_a = splitm.column()
        col_b = splitm.column()
        col_a.prop(self, 'mat_fav3_bool', text="")
        if not self.mat_fav3_bool:
            split = col_b.split(factor=0.65)
            col_1 = split.column()
            col_2 = split.column()
            row = col_1.row()
            row.enabled = self.mat_fav3_bool
            row.prop(self, 'mat_fav3_name', text="")
            row = col_2.row()
            row.enabled = self.mat_fav3_bool
            row.prop(self, 'mat_fav3_stkcolor', text="")
            row.prop(self, 'mat_fav3_fillcolor', text="")
        else:
            row = col_b.row()
            row.prop(self, 'mat_fav3_name', text="")
            row = mat_box.row()
            row.label(text=" ")
            row.prop(self, 'mat_fav3_stkbool', text="Stroke")
            row.prop(self, 'mat_fav3_stkcolor', text="")
            row = mat_box.row()
            row.label(text=" ")
            row.prop(self, 'mat_fav3_fillbool', text="Fill")
            row.prop(self, 'mat_fav3_fillcolor', text="")


class StoryboardCameraElements(PropertyGroup):
    """sb_objects of cameras"""  # bpy.types.Camera.sb_objects
    name: StringProperty(
        name=" ",
        default="Unknown",
    )
    # data: StringProperty(
    #    name=" ",
    #    default="Unknown",
    # )
    focus: BoolProperty(
        name="focus",
        default=False,
    )
    obj: PointerProperty(
        name="object",
        type=bpy.types.Object
    )


class StoryboardData(PropertyGroup):
    """sbdata property group of the scene"""  # bpy.context.scene.sb_data
    shots: IntProperty(
        name='Storyboard Panels',
        default=0,
    )
    created: BoolProperty(
        default=False,
    )
    basename: StringProperty(
        name='Names',
        default="Shot"
    )
    columns: IntProperty(
        name='Storyboard Columns',
        default=4,
    )
    rows: IntProperty(
        name='Storyboard Rows',
        default=3,
    )
    spacing: FloatProperty(
        name='Storyboard Spacing',
        description="Space between panels",
        default=0.1,
        min=0.0, soft_max=1.0,
    )
    xoffset: FloatProperty(
        name='X Offset',
        default=1.0,
    )
    xspace: FloatProperty(
        name='Storyboard X Spacing',
    )
    verticalspace: FloatProperty(
        name='Vertical Spacing',
        default=-1.8,
    )
    yspace: FloatProperty(
        name='Storyboard Y Spacing',
    )
    fast_draw: BoolProperty(
        name="Fast Draw Mode",
        description="Start in drawing mode with new Grease Pencil object",
        default=True,
    )
    fastdraw_layer: StringProperty(
        name="Fast Draw Layer",
        description="Layer to use for fast draw mode",
        default=""
    )
    cam_views: EnumProperty(
        name="Camera List",
        description="List of cameras in the scene",
        items=[
            ('ALL', "All", ""),
            ('STORYBOARD', "Storyboard", ""),
        ],
        default='ALL'
    )
    cam_rendersettings: EnumProperty(
        name="Storyboard Render Settings",
        description="Render settings for Storyboad Camera",
        items=[
            ('SCENE', "Scene", ""),
            ('OPTONE', "Option 1", ""),
            ('OPTTWO', "Option 2", ""),
        ],
        update=update_scene_res,
        default='SCENE'
    )
    scene_res_saved: BoolProperty(
        default=False,
    )
    scene_res_x: IntProperty(
        name='Scene Resolution X',
        # default=1920,
    )
    scene_res_y: IntProperty(
        name='Scene Resolution Y',
        # default=1080,
    )
    optone_res_x: IntProperty(
        name='Option 1 Resolution X',
    )
    optone_res_y: IntProperty(
        name='Option 1 Resolution Y',
    )
    opttwo_res_x: IntProperty(
        name='Option 2 Resolution X',
    )
    opttwo_res_y: IntProperty(
        name='Option 2 Resolution Y',
    )
    marker_view: EnumProperty(
        name="Marker List",
        description="List of markers in the scene",
        items=[
            ('ALL', "All", "Show all markers in the scene"),
            ('CAMERAS', "Cameras", "Select only markers bound to cameras"),
            ('MARKERS', "Markers", "Select only simple markers"),
        ],
        default='ALL'
    )
    # mark_banks: EnumProperty(
    #     name="Limit Marker List",
    #     description="Limit the list of markers in the scene",
    #     items=[
    #         ('ABANK', "1-10", "Show first 10 markers in the scene"),
    #         ('BBANK', "11-20", "Show second 10 markers in the scene"),
    #         ('CBANK', "21-30", "Show third 10 markers in the scene"),
    #     ],
    #     default='ABANK'
    # )
    marker_ui_frames: BoolProperty(
        name="Marker Frame Visibilty",
        description="Edit marker frame numbers",
        default=False,
    )

    original_collection: StringProperty(
        name='Original Collection',
    )
    images_path: StringProperty(
        name='Images Folder',
        description="Path to folder of images for import",
        subtype='DIR_PATH',
        default='//'
    )
    export_path: StringProperty(
        name='Export Folder',
        description="Folder path to save exported file",
        subtype='DIR_PATH',
        default='//'
    )


class StoryboardOutline(PropertyGroup):
    name: StringProperty()
    frame: IntProperty()
    active_color: FloatVectorProperty(
        name='Active',
        subtype='COLOR',
        default=(0.127, 0.301, 0.847)
    )


class StoryboardCamViews(PropertyGroup):
    name: StringProperty()
    cam_pos: FloatVectorProperty(
        name='Position',
        default=(0.0, 0.0, 0.0)
    )
    ortho_scale: FloatProperty(
        name='Ortho Scale',
        description="Orthographic Camera Scale (similar to zoom)",
        default=16.0,
        min=0.001,
    )
    cam_active: BoolProperty(default=True)
    cam_render: BoolProperty(
        name="Render",
        description="Enable or disable for rendering",
        default=True
    )
    frame: IntProperty(
        name="Frame",
        description="Frame number to use for rendering",
        soft_min=1,
        min=0,
        default=1
    )


class StoryboardPerspective(PropertyGroup):
    name: StringProperty()
    gpname: StringProperty()
    number: IntProperty()
    active_color: FloatVectorProperty(
        name='Active',
        subtype='COLOR',
        default=(0.127, 0.301, 0.847)
    )
    inactive_color: FloatVectorProperty(
        name='Inactive',
        subtype='COLOR',
        default=(0.127, 0.127, 0.127)
    )


def storyboard_find_gpencil_poll(self, object):
    return object.type == 'GPENCIL'


def storyboard_find_camera_poll(self, object):
    return object.type == 'CAMERA'


def storyboard_find_object_poll(self, object):
    return object.type == 'OBJECT'


classes = (
    StoryboardAddonPreferences,
    StoryboardCameraElements,
    StoryboardData,
    StoryboardOutline,
    StoryboardCamViews,
    StoryboardPerspective,
)


def register():
    bpy.types.Scene.storyboard_basename = bpy.props.StringProperty(
        name='Name of boards',
    )
    bpy.types.Scene.storyboard_columns = bpy.props.IntProperty(
        name='Storyboard Columns',
        default=4,
    )
    bpy.types.Scene.storyboard_rows = bpy.props.IntProperty(
        name='Storyboard Rows',
        default=3,
    )
    bpy.types.Scene.storyboard_count = bpy.props.IntProperty(
        name='Storyboard Count',
    )
    bpy.types.Scene.storyboard_images_path = bpy.props.StringProperty(
        name='Images Folder',
        subtype='DIR_PATH',
    )
    bpy.types.Scene.animatic = bpy.props.BoolProperty(
        name='Make Animatic',
        description="Create timeline markers and bind cameras to them",
        default=True,
    )
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.sb_data = PointerProperty(type=StoryboardData)
    bpy.types.Scene.sb_borders = CollectionProperty(type=StoryboardOutline)
    bpy.types.Scene.sb_bindex = IntProperty(name="Index for sb_borders", default=0)
    bpy.types.Scene.sb_camviews = CollectionProperty(type=StoryboardCamViews)
    bpy.types.Scene.sb_cvindex = IntProperty(name="Storyboard camera view", default=0)
    bpy.types.Scene.sb_ppoints = CollectionProperty(type=StoryboardPerspective)
    bpy.types.Scene.sb_pindex = IntProperty(name="Index for sb_ppoints", default=0)
    bpy.types.Scene.sb_pline = FloatProperty(name='Line Thickness', default=6.0)
    bpy.types.Scene.sb_pactive_color = FloatVectorProperty(
        name='Active',
        subtype='COLOR',
        default=(0.127, 0.301, 0.847, 0.5),
        size=4,
        min=0, max=1,
    )
    bpy.types.Scene.sb_pinactive_color = FloatVectorProperty(
        name='Inactive',
        subtype='COLOR',
        default=(0.127, 0.127, 0.127, 0.5),
        size=4,
        min=0, max=1,
    )
    bpy.types.Camera.sb_objects = CollectionProperty(type=StoryboardCameraElements)
    bpy.types.Scene.panelCopyObj = bpy.props.PointerProperty(
        name='GP Object',
        description="Grease Pencil object to Copy or Move",
        # type=bpy.types.Object,
        type=bpy.types.GreasePencil,
        # poll=storyboard_find_gpencil_poll
    )

    bpy.types.Scene.panelPasteCam = bpy.props.PointerProperty(
        name='Shot',
        description="Copy GP Object to this shot",
        type=bpy.types.Camera,
        # poll=storyboard_find_object_poll
    )

    bpy.types.Scene.panelSwapACam = bpy.props.PointerProperty(
        name='Shot A',
        type=bpy.types.Camera,
        # poll=storyboard_find_camera_poll
    )

    bpy.types.Scene.panelSwapBCam = bpy.props.PointerProperty(
        name='Shot B',
        type=bpy.types.Camera,
        # poll=storyboard_find_camera_poll
    )

    bpy.types.Scene.panelLoadImage = bpy.props.PointerProperty(
        name='Panel',
        description="Select board to import image onto",
        type=bpy.types.Object,
    )


def unregister():
    del bpy.types.Scene.storyboard_basename
    del bpy.types.Scene.storyboard_rows
    del bpy.types.Scene.storyboard_columns
    del bpy.types.Scene.storyboard_count
    del bpy.types.Scene.storyboard_images_path
    del bpy.types.Scene.animatic
    del bpy.types.Scene.sb_data
    del bpy.types.Scene.sb_borders
    del bpy.types.Scene.sb_bindex
    del bpy.types.Scene.sb_camviews
    del bpy.types.Scene.sb_cvindex
    del bpy.types.Scene.sb_ppoints
    del bpy.types.Scene.sb_pindex
    del bpy.types.Scene.sb_pline
    del bpy.types.Scene.sb_pactive_color
    del bpy.types.Scene.sb_pinactive_color
    del bpy.types.Scene.panelCopyObj
    del bpy.types.Scene.panelPasteCam
    del bpy.types.Scene.panelSwapACam
    del bpy.types.Scene.panelSwapBCam
    del bpy.types.Camera.sb_objects
    for cls in classes:
        bpy.utils.unregister_class(cls)
