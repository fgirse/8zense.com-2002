import bpy
from bpy.props import IntProperty, StringProperty, CollectionProperty
from bpy.types import Operator, PropertyGroup, UIList
import math


def update_angle_guide(self, context):
    bpy.context.scene.tool_settings.gpencil_sculpt.guide.angle = self.angle_guide
    bpy.data.objects['Angle Guide'].rotation_euler[1] = self.angle_guide


def make_gp_material(colorname, rgba):

    # Create material for grease pencil
    if colorname in bpy.data.materials.keys():
        gp_mat = bpy.data.materials[colorname]
    else:
        gp_mat = bpy.data.materials.new(colorname)

    if not gp_mat.is_grease_pencil:
        bpy.data.materials.create_gpencil_data(gp_mat)
        gp_mat.grease_pencil.color = rgba

    return gp_mat


def make_gp_strokes(frame, x1, y1, z1, x2, y2, z2):

    scn = bpy.context.scene
    # Create Grease Pencil strokes
    stroke = frame.strokes.new()
    stroke.line_width = scn.sb_pline
    if (z1 == round(z2, 1)):
        stroke.line_width = 2 * scn.sb_pline
    stroke.material_index = 1
    stroke.points.add(2)
    stroke.points.foreach_set("co", (x1, y1, z1, x2, y2, z2))

    return


def make_gp_radiant(frame, step, magnitude):

    flip = True
    for a in range(0, 360, step):
        offset = a / 90
        voffset = offset - int(offset)
        if flip:
            vstart = 0.02
        else:
            vstart = 0.08
        if voffset:
            # bx = math.cos(math.radians(a)) * 0.02
            # bz = math.sin(math.radians(a)) * 0.02
            bx = math.cos(math.radians(a)) * vstart
            bz = math.sin(math.radians(a)) * vstart
        else:
            bx = 0
            bz = 0
        vx = math.cos(math.radians(a)) * magnitude
        vz = math.sin(math.radians(a)) * magnitude
        # aspect_ratio = 0.5625
        # vz = vz * aspect_ratio
        make_gp_strokes(frame, bx, 0, bz, vx, 0, vz)
        flip = not flip

    return


def change_gp_mat(gp_obj, mat_idx):

    # Change all strokes to different material
    for s, stk in enumerate(gp_obj.strokes):
        gp_obj.strokes[s].material_index = mat_idx

    return


class STORYBOARD_OT_PerspActions(Operator):
    """Move items up and down, add and remove"""
    bl_idname = "sboard.persplist_action"
    bl_label = "Perspective List Actions"
    bl_description = "Move items up and down, add and remove"
    bl_options = {'REGISTER'}

    action: bpy.props.EnumProperty(
        items=(
            ('UP', "Up", ""),
            ('DOWN', "Down", ""),
            ('REMOVE', "Remove", ""),
            ('ADD', "Add", "")))

    def invoke(self, context, event):
        scn = bpy.context.scene
        idx = scn.sb_pindex

        try:
            item = scn.sb_ppoints[idx]
        except IndexError:
            pass
        else:
            if self.action == 'DOWN' and idx < len(scn.sb_ppoints) - 1:
                item_next = scn.sb_ppoints[idx+1].name
                scn.sb_ppoints.move(idx, idx+1)
                scn.sb_pindex += 1
                info = 'Item "%s" moved to position %d' % (
                    item.name, scn.sb_pindex + 1)
                self.report({'INFO'}, info)

            elif self.action == 'UP' and idx >= 1:
                item_prev = scn.sb_ppoints[idx-1].name
                scn.sb_ppoints.move(idx, idx-1)
                scn.sb_pindex -= 1
                info = 'Item "%s" moved to position %d' % (
                    item.name, scn.sb_pindex + 1)
                self.report({'INFO'}, info)

            elif self.action == 'REMOVE':
                # rinfo = 'Item "%s" removed from list' % (
                #     scn.sb_ppoints[idx].name)
                gp_name = scn.sb_ppoints[idx].gpname
                datobj = bpy.data.objects
                try:
                    if datobj[gp_name]:
                        datobj.remove(datobj[gp_name], do_unlink=True)
                except KeyError:
                    pass
                scn.sb_pindex -= 1
                scn.sb_ppoints.remove(idx)
                if (scn.sb_pindex == -1) and (len(scn.sb_ppoints) > 0):
                    scn.sb_pindex += 1
                # self.report({'INFO'}, rinfo)

        if self.action == 'ADD':
            # Newest code moved to own class
            item = scn.sb_ppoints.add()
            bpy.context.scene.cursor.rotation_euler = (0, 0, 0)
            thePoint = bpy.ops.object.empty_add(type='CONE', align='CURSOR')
            print(thePoint)
            item.name = "point %s" % (len(scn.sb_ppoints))
            scn.sb_pindex = len(scn.sb_ppoints)-1
            info = '"%s" added to list' % (item.name)
            self.report({'INFO'}, info)

        return {"FINISHED"}


class GPENCIL_OT_addbasic(Operator):
    """Create a blank Grease Pencil object with materials"""
    bl_idname = "gpencil.addbasic"
    bl_label = "Add Basic Grease Pencil"
    bl_description = "Create a blank Grease Pencil object with materials"

    def execute(self, context):

        context = bpy.context
        space = context.space_data
        cam = bpy.context.scene.camera
        storyboard = bpy.context.scene.sb_data
        coll_name = "Storyboard_Panels"
        gpname = "GPencil"
        if cam:
            gpname = cam.name + " GPencil"

        #make_gp_mat("White", (1.0, 1.0, 1.0, 1))
        #make_gp_mat("Grey Lightest", (0.515, 0.515, 0.515, 1))
        #make_gp_mat("Grey Light", (0.319, 0.319, 0.319, 1))
        #make_gp_mat("Grey Mid", (0.169, 0.169, 0.169, 1))
        #make_gp_mat("Grey Dark", (0.072, 0.072, 0.072, 1))
        #make_gp_mat("Grey Darkest", (0.019, 0.019, 0.019, 1))
        gp_mat = make_gp_mat("Black", (0.0, 0.0, 0.0, 1))

        # Add grease pencil object
        gp_data = bpy.data.grease_pencils.new(gpname)
        gp_ob = bpy.data.objects.new(gpname, gp_data)
        print(gp_ob.location)
        if cam:
            gp_ob.location[0] = cam.location[0]
            gp_ob.location[2] = cam.location[2]
        # context.scene.collection.objects.link(gp_ob)
        # bpy.ops.collection.objects_remove_all()
        if coll_name in bpy.data.collections:
            bpy.data.collections[coll_name].objects.link(gp_ob)
        else:
            bpy.data.collections["Collection"].objects.link(gp_ob)
        if space.local_view:
            gp_ob.local_view_set(space, True)

        for ob in context.selected_objects:
            ob.select_set(False)
        gp_ob.select_set(True)
        context.view_layer.objects.active = gp_ob
        if storyboard.created:
            elem = cam.data.sb_objects.add()
            elem.name = gp_ob.name
            elem.obj = gp_ob
        bpy.ops.object.mode_set(mode='PAINT_GPENCIL')

        # Assign the material to the grease pencil for drawing
        gp_data.materials.append(gp_mat)
        gp_mat = make_gp_mat("Grey Darkest", (0.019, 0.019, 0.019, 1))
        gp_data.materials.append(gp_mat)
        gp_mat = make_gp_mat("Grey Dark", (0.072, 0.072, 0.072, 1))
        gp_data.materials.append(gp_mat)
        gp_mat = make_gp_mat("Grey Mid", (0.169, 0.169, 0.169, 1))
        gp_data.materials.append(gp_mat)
        gp_mat = make_gp_mat("Grey Light", (0.319, 0.319, 0.319, 1))
        gp_data.materials.append(gp_mat)
        gp_mat = make_gp_mat("Grey Lightest", (0.515, 0.515, 0.515, 1))
        gp_data.materials.append(gp_mat)
        gp_mat = make_gp_mat("White", (1.0, 1.0, 1.0, 1))
        gp_data.materials.append(gp_mat)

        # Draw, using the material defined
        bpy.ops.gpencil.draw(wait_for_input=False)
        bpy.context.object.active_material_index = 1       # <===== TRY THIS

        bpy.context.space_data.show_region_tool_header = True
        # SURFACE does NOT work well with boards
        # origin of board best
        #bpy.context.scene.tool_settings.gpencil_stroke_placement_view3d = 'SURFACE'

        return {'FINISHED'}


class STORYBOARD_OT_AddPerspective(Operator):
    """Add a perspective point"""
    bl_idname = "sboard.persplist_add"
    bl_label = "Add a perspective point"

    def execute(self, context):
        scn = bpy.context.scene
        idx = scn.sb_pindex
        numlist = []
        context = bpy.context
        space = context.space_data
        cam = bpy.context.scene.camera
        storyboard = bpy.context.scene.sb_data
        coll_name = "Storyboard_Panels"

        try:
            item = scn.sb_ppoints[idx]
        except IndexError:
            pass

        # Add section
        item = scn.sb_ppoints.add()

        # Naming section
        pointsum = len(scn.sb_ppoints)
        if pointsum > 1:
            for p in range(0, (pointsum - 1)):
                chknumber = scn.sb_ppoints[p].number
                numlist.append(chknumber)
            numlist.sort()
            i = 0
            while i < (pointsum):
                try:
                    peek = numlist[i]
                except IndexError:
                    item.number = pointsum
                    item.name = "point %s" % (pointsum)
                if not (peek == (i + 1)):
                    item.number = (i + 1)
                    item.name = "point %s" % (i + 1)
                    break
                i += 1
        else:
            item.number = 1
            item.name = "point %s" % (1)
        scn.sb_pindex = len(scn.sb_ppoints)-1
        # info = '"%s" added to list' % (item.name)
        # self.report({'INFO'}, info)

        # Add grease pencil object
        gpname = "Vanishing " + item.name
        if cam:
            gpname = cam.name + " Vanishing " + item.name
        gp_data = bpy.data.grease_pencils.new(gpname)
        gp_ob = bpy.data.objects.new(gpname, gp_data)
        item.gpname = gpname
        if cam:
            gp_ob.location[0] = cam.location[0]
            gp_ob.location[2] = cam.location[2]
        if coll_name in bpy.data.collections:
            bpy.data.collections[coll_name].objects.link(gp_ob)
        else:
            bpy.data.collections["Collection"].objects.link(gp_ob)
        if space.local_view:
            gp_ob.local_view_set(space, True)
        for ob in context.selected_objects:
            ob.select_set(False)
        gp_ob.select_set(True)
        context.view_layer.objects.active = gp_ob
        bpy.ops.object.mode_set(mode='PAINT_GPENCIL')

        mat_active = scn.sb_pactive_color
        gp_mat_act = make_gp_material("Active Guide", mat_active)
        gp_data.materials.append(gp_mat_act)
        mat_inactive = scn.sb_pinactive_color
        gp_mat_inact = make_gp_material("Inactive Guide", mat_inactive)
        gp_data.materials.append(gp_mat_inact)
        bpy.context.object.active_material_index = 0
        bpy.ops.gpencil.draw(wait_for_input=False)
        bpy.context.space_data.show_region_tool_header = True
        layer = gp_data.layers.new("Guide MASK", set_active=False)
        layer = gp_data.layers.new("Vanishing Point Guide", set_active=True)

        # make_gp_strokes for grid lines
        frame = layer.frames.new(1)

        # stroke = frame.strokes.new()
        # stroke.line_width = scn.sb_pline
        # stroke.points.add(2)
        # stroke.points.foreach_set("co", (0, 0, 0, 10, 0, 0))

        # Lines above are now a function
        # make_gp_strokes(frame, x1, y1, z1, x2, y2, z2)

        # Extent of line
        magnitude = 4.0
        # number of degrees
        step = 3
        make_gp_radiant(frame, step, magnitude)

        # bpy.data.materials["Active Guide"].grease_pencil.lock = True
        # bpy.data.materials["Inactive Guide"].grease_pencil.lock = True

        # move to 3D cursor and put into background
        gp_ob.location = scn.cursor.location
        gp_ob.location[1] = 0.025
        # hide from rendering
        bpy.context.object.hide_render = True
        bpy.ops.gpencil.paintmode_toggle()

        return {'FINISHED'}


class STORYBOARD_OT_GuidePerspective(Operator):
    """Guide locks Grease Pencil stokes to perspective point"""

    bl_idname = "sboard.guidepersp"
    bl_label = "Lock Guide"

    def execute(self, context):
        scn = bpy.context.scene
        idx = scn.sb_pindex
        try:
            item = scn.sb_ppoints[idx]
            # print("GOOD item")
            # print(item.gpname)
            for p, pts in enumerate(scn.sb_ppoints):
                other = scn.sb_ppoints[p]
                gpobj = bpy.data.objects[other.gpname].data
                gplyr = gpobj.layers['Vanishing Point Guide'].frames[0]
                change_gp_mat(gplyr, 1)

            settings = bpy.context.scene.tool_settings.gpencil_sculpt.guide
            settings.type = 'RADIAL'
            settings.reference_point = 'OBJECT'
            settings.reference_object = bpy.data.objects[item.gpname]
            settings.use_guide = True
            gp_obj = bpy.data.objects[item.gpname].data
            gp_lyr = gp_obj.layers['Vanishing Point Guide'].frames[0]
            change_gp_mat(gp_lyr, 0)
        except IndexError:
            # print("BAD item")
            pass

        return {'FINISHED'}


class STORYBOARD_OT_GuideInactive(Operator):
    """Grease Pencil Guide material set to Inactive"""

    bl_idname = "sboard.guideinactive"
    bl_label = "Guide Inactive"

    def execute(self, context):
        scn = bpy.context.scene
        idx = scn.sb_pindex
        try:
            item = scn.sb_ppoints[idx]
            settings = bpy.context.scene.tool_settings.gpencil_sculpt.guide
            settings.use_guide = False
            settings.reference_object = None
            # gp_obj = bpy.data.objects[item.gpname].data
            # gp_lyr = gp_obj.layers['Vanishing Point Guide'].frames[0]
            # change_gp_mat(gp_lyr, 1)
            for p, pts in enumerate(scn.sb_ppoints):
                other = scn.sb_ppoints[p]
                gpobj = bpy.data.objects[other.gpname].data
                gplyr = gpobj.layers['Vanishing Point Guide'].frames[0]
                change_gp_mat(gplyr, 1)
        except IndexError:
            pass

        return {'FINISHED'}


class STORYBOARD_OT_GuideGrid(Operator):
    """Guide locks Grease Pencil stokes to horizontal and vertical"""

    bl_idname = "sboard.guidegrid"
    bl_label = "Grease Pencil Guide Grid"

    def execute(self, context):
        settings = bpy.context.scene.tool_settings.gpencil_sculpt.guide
        settings.type = 'GRID'
        settings.use_guide = True

        return {'FINISHED'}


class STORYBOARD_OT_AngleGuide(Operator):
    """Create a Grease Pencil guide object for angles"""
    bl_idname = "gpencil.angleguide"
    bl_label = "Add Grease Pencil Angle Guide"
    bl_description = "Create a Grease Pencil guide object for angles"

    def execute(self, context):

        scn = bpy.context.scene
        gpname = "Angle Guide"
        context = bpy.context
        space = context.space_data
        cam = bpy.context.scene.camera
        coll_name = "Storyboard_Panels"

        # if cam:
        #     gpname = cam.name + " Angle Guide"
        gp_data = bpy.data.grease_pencils.new(gpname)
        gp_ob = bpy.data.objects.new(gpname, gp_data)
        # if cam:
        #     gp_ob.location[0] = cam.location[0]
        #     gp_ob.location[2] = cam.location[2]
        if coll_name in bpy.data.collections:
            bpy.data.collections[coll_name].objects.link(gp_ob)
        else:
            bpy.data.collections["Collection"].objects.link(gp_ob)
        if space.local_view:
            gp_ob.local_view_set(space, True)
        for ob in context.selected_objects:
            ob.select_set(False)
        gp_ob.select_set(True)
        context.view_layer.objects.active = gp_ob
        bpy.ops.object.mode_set(mode='PAINT_GPENCIL')

        mat_active = scn.sb_pactive_color
        gp_mat_act = make_gp_material("Active Guide", mat_active)
        gp_data.materials.append(gp_mat_act)
        mat_inactive = scn.sb_pinactive_color
        gp_mat_inact = make_gp_material("Inactive Guide", mat_inactive)
        gp_data.materials.append(gp_mat_inact)
        bpy.context.object.active_material_index = 0
        bpy.ops.gpencil.draw(wait_for_input=False)
        bpy.context.space_data.show_region_tool_header = True
        layer = gp_data.layers.new("Guide MASK", set_active=False)
        layer = gp_data.layers.new("Angle Guide", set_active=True)

        frame = layer.frames.new(1)

        make_gp_strokes(frame, 0, 0, 0, 10, 0, 0)
        make_gp_strokes(frame, 0, 0, 0, -10, 0, 0)
        # make_gp_strokes(frame, 0, 0, 0.3, 10, 0, 0.3)
        # make_gp_strokes(frame, 0, 0, 0.3, -10, 0, 0.3)
        # make_gp_strokes(frame, 0, 0, -0.3, 10, 0, -0.3)
        # make_gp_strokes(frame, 0, 0, -0.3, -10, 0, -0.3)

        # move to 3D cursor and put into background
        gp_ob.location = scn.cursor.location
        gp_ob.location[1] = 0.025
        gp_ob.rotation_euler[2] = math.radians(180)
        # hide from rendering
        bpy.context.object.hide_render = True
        bpy.ops.gpencil.paintmode_toggle()

        return {'FINISHED'}


class STORYBOARD_OT_AddOutline(Operator):
    """Add outline to current board"""

    bl_idname = "sb_borders.add_outline"
    bl_label = "Add Outline to Board"

    def execute(self, context):
        activecam_name = ""
        cam = bpy.context.scene.camera
        if (cam and cam.type == 'CAMERA'):
            activecam_name = cam.name

        border = context.scene.sb_borders.add()
        border.name = activecam_name
        border.frame = 999

        return {'FINISHED'}


class STORYBOARD_OT_MakeOutlines(Operator):
    """Add outlines to ALL boards"""

    bl_idname = "sb_borders.make_outlines"
    bl_label = "Add Outlines to ALL Boards"

    def execute(self, context):
        context.scene.sb_borders.add()
        context.scene.sb_borders.add()

        return {'FINISHED'}


class STORYBOARD_OT_DeleteOutline(Operator):
    """Delete the selected outline from the board"""

    bl_idname = "sb_borders.delete_outline"
    bl_label = "Delete Selected"

    @classmethod
    def poll(cls, context):
        return context.scene.sb_borders

    def execute(self, context):
        sb_borders = context.scene.sb_borders
        index = context.scene.sb_bindex

        sb_borders.remove(index)
        context.scene.sb_bindex = min(max(0, index - 1), len(sb_borders) - 1)

        return{'FINISHED'}


class STORYBOARD_OT_DeleteAllOutlines(Operator):
    """Delete ALL outlines from the board"""

    bl_idname = "sb_borders.delete_all"
    bl_label = "Delete ALL Outlines"

    @classmethod
    def poll(cls, context):
        return context.scene.sb_borders

    def execute(self, context):
        sb_borders = context.scene.sb_borders
        index = context.scene.sb_bindex

        sb_borders.remove(index)
        context.scene.sb_bindex = min(max(0, index - 1), len(sb_borders) - 1)

        return {'FINISHED'}


classes = (
    STORYBOARD_OT_PerspActions,
    STORYBOARD_OT_AddPerspective,
    STORYBOARD_OT_GuidePerspective,
    STORYBOARD_OT_GuideInactive,
    STORYBOARD_OT_GuideGrid,
    STORYBOARD_OT_AngleGuide,
    STORYBOARD_OT_AddOutline,
    STORYBOARD_OT_MakeOutlines,
    STORYBOARD_OT_DeleteOutline,
    STORYBOARD_OT_DeleteAllOutlines,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in classes:
        bpy.utils.unregister_class(cls)


bpy.types.Scene.angle_guide = bpy.props.FloatProperty(
    min=math.radians(-180),
    max=math.radians(180),
    unit='ROTATION',
    update=update_angle_guide)
