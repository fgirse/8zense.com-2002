import pathlib
import os
import math
import bpy
from bpy.props import StringProperty, BoolProperty, EnumProperty
from bpy.types import Operator
from mathutils import Vector


def ShowMessageBox(message="", title="Message Box", icon='INFO'):

    def draw(self, context):
        self.layout.label(text=message)

    bpy.context.window_manager.popup_menu(draw, title=title, icon=icon)


def jump_marker(arg):
    bpy.ops.screen.marker_jump(next=arg)


def select_markers_after(frame):
    for m in bpy.context.scene.timeline_markers:
        if m.frame > frame:
            m.select = True
        else:
            m.select = False


def update_text_editor():
    cameras = [o for o in bpy.context.scene.objects if o.type == 'CAMERA']
    if len(cameras) > 0:
        curcam = bpy.context.scene.camera.name  # default Camera has no name!
        for area in bpy.context.screen.areas:
            if area.type == 'TEXT_EDITOR':
                try:
                    area.spaces.active.text = bpy.data.texts[curcam]
                    break
                except KeyError:
                    print("No text for selected camera.")


def select_prev_cam(context):
    scene = context.scene
    cameras = []
    allcams = [a for a in scene.objects if a.type == 'CAMERA']
    storyboard = bpy.context.scene.sb_data
    if storyboard.cam_views == 'ALL':
        # cameras = [o for o in bpy.context.scene.objects if o.type == 'CAMERA']
        if len(allcams) > 0:
            curcam = bpy.context.scene.camera.name
            for camera in allcams:
                if camera.name == curcam:
                    prevcam = allcams.index(camera) - 1
                    if prevcam > -1:
                        bpy.context.scene.camera = allcams[prevcam]
    else:
        for s in allcams:
            if s.name == "Storyboard":
                cameras.append(s)
        mlist = scene.timeline_markers
        markerlist = sorted(mlist, key=lambda mlist: mlist.frame)
        for m in markerlist:
            if m.camera:
                cameras.append(m.camera)
        if len(cameras) > 0:
            curcam = bpy.context.scene.camera
            if curcam not in cameras:
                bpy.context.scene.camera = cameras[0]
            for camera in cameras:
                if camera.name == curcam.name:
                    prevcam = cameras.index(camera) - 1
                    if prevcam > -1:
                        bpy.context.scene.camera = cameras[prevcam]


def select_next_cam(context):
    scene = context.scene
    cameras = []
    allcams = [a for a in scene.objects if a.type == 'CAMERA']
    storyboard = bpy.context.scene.sb_data
    if storyboard.cam_views == 'ALL':
        # cameras = [o for o in bpy.context.scene.objects if o.type == 'CAMERA']
        if len(allcams) > 0:
            curcam = bpy.context.scene.camera.name
            for camera in allcams:
                if camera.name == curcam:
                    nextcam = 1 + allcams.index(camera)
                    if nextcam < len(allcams):
                        bpy.context.scene.camera = allcams[nextcam]
    else:
        for s in allcams:
            if s.name == "Storyboard":
                cameras.append(s)
        mlist = scene.timeline_markers
        markerlist = sorted(mlist, key=lambda mlist: mlist.frame)
        for m in markerlist:
            if m.camera:
                cameras.append(m.camera)
        if len(cameras) > 0:
            curcam = bpy.context.scene.camera
            if curcam not in cameras:
                bpy.context.scene.camera = cameras[0]
            for camera in cameras:
                if camera.name == curcam.name:
                    nextcam = 1 + cameras.index(camera)
                    if nextcam < len(cameras):
                        bpy.context.scene.camera = cameras[nextcam]


def store_prevcollection(self):
    """Stores the active scene collection name."""
    prev_collection_name = bpy.context.view_layer.active_layer_collection.name
    storyboard = bpy.context.scene.sb_data
    storyboard.original_collection = prev_collection_name


def makeboard_collection(col_name):
    """Makes a new active scene collection."""
    try:
        scene_col = bpy.context.scene.collection.children[col_name]
        # possible alt method:
        # scene_col = bpy.data.collections[col_name]
    except KeyError:
        scene_col = bpy.data.collections.new(col_name)
        # scene_col = bpy.data.collections.new(name = col_name)
        bpy.context.scene.collection.children.link(scene_col)

    layer_collection = bpy.context.view_layer.layer_collection.children[
        scene_col.name]
    bpy.context.view_layer.active_layer_collection = layer_collection


def select_collection(col_name):
    """Selects an existing scene collection and makes it active."""
    scene_col = bpy.data.collections[col_name]
    layer_collection = bpy.context.view_layer.layer_collection.children[scene_col.name]
    bpy.context.view_layer.active_layer_collection = layer_collection


def make_gp_mat(colorname, s_bool, s_rgba, f_bool, f_rgba):
    # Create material for grease pencil
    if colorname in bpy.data.materials.keys():
        gp_mat = bpy.data.materials[colorname]
    else:
        gp_mat = bpy.data.materials.new(colorname)

    if not gp_mat.is_grease_pencil:
        bpy.data.materials.create_gpencil_data(gp_mat)
        if s_bool:
            gp_mat.grease_pencil.color = s_rgba
        if f_bool:
            gp_mat.grease_pencil.fill_color = f_rgba
    return gp_mat


def fastgpdraw(gp_layer):
    """Adds a Basic Grease Pencil Object"""
    gplayers_list = []
    context = bpy.context
    space = context.space_data
    cam = bpy.context.scene.camera
    storyboard = bpy.context.scene.sb_data
    preferences = bpy.context.preferences.addons[__package__].preferences
    coll_name = "Storyboard_Elements"
    gpname = "GPencil"
    if cam:
        gpname = cam.name + " GPencil"
    # Add grease pencil object
    gp_data = bpy.data.grease_pencils.new(gpname)
    gp_ob = bpy.data.objects.new(gpname, gp_data)
    if cam:
        gp_ob.location[0] = cam.location[0]
        gp_ob.location[2] = cam.location[2]
    if coll_name in bpy.data.collections:
        bpy.data.collections[coll_name].objects.link(gp_ob)
    else:
        bpy.data.collections["Collection"].objects.link(gp_ob)
    if space.local_view:
        gp_ob.local_view_set(space, True)
    for ob in context.selected_objects:
        ob.select_set(False)
    gp_ob.select_set(True)
    context.view_layer.objects.active = gp_ob
    if storyboard.created:
        elem = cam.data.sb_objects.add()
        elem.name = gp_ob.name
        elem.obj = gp_ob
    bpy.ops.object.mode_set(mode='PAINT_GPENCIL')
    # Add GP layers
    if preferences.gplayer_fav5_bool:
        gplayer_name = preferences.gplayer_fav5_name
        layer = gp_data.layers.new(gplayer_name, set_active=True)
    if preferences.gplayer_fav4_bool:
        gplayer_name = preferences.gplayer_fav4_name
        layer = gp_data.layers.new(gplayer_name, set_active=True)
    if preferences.gplayer_fav3_bool:
        gplayer_name = preferences.gplayer_fav3_name
        layer = gp_data.layers.new(gplayer_name, set_active=True)
    if preferences.gplayer_fav2_bool:
        gplayer_name = preferences.gplayer_fav2_name
        layer = gp_data.layers.new(gplayer_name, set_active=True)
    if preferences.gplayer_fav1_bool:
        gplayer_name = preferences.gplayer_fav1_name
        layer = gp_data.layers.new(gplayer_name, set_active=True)
    if preferences.gplayer_fav_bool:
        gplayer_name = preferences.gplayer_fav_name
        layer = gp_data.layers.new(gplayer_name, set_active=True)
    if preferences.mat_blk_bool:
        stroke_bool = True
        fill_bool = False
        gp_mat = make_gp_mat("Black", stroke_bool,
                             (0.0, 0.0, 0.0, 1), fill_bool, (0.0, 0.0, 0.0, 1))
        gp_data.materials.append(gp_mat)
    if preferences.mat_gry_bool:
        stroke_bool = True
        fill_bool = False
        gp_mat = make_gp_mat("Grey Darkest", stroke_bool, (0.019,
                                                           0.019, 0.019, 1), fill_bool, (0.019, 0.019, 0.019, 1))
        gp_data.materials.append(gp_mat)
        gp_mat = make_gp_mat("Grey Dark", stroke_bool, (0.072,
                                                        0.072, 0.072, 1), fill_bool, (0.072, 0.072, 0.072, 1))
        gp_data.materials.append(gp_mat)
        gp_mat = make_gp_mat("Grey Mid", stroke_bool, (0.169,
                                                       0.169, 0.169, 1), fill_bool, (0.169, 0.169, 0.169, 1))
        gp_data.materials.append(gp_mat)
        gp_mat = make_gp_mat("Grey Light", stroke_bool, (0.319,
                                                         0.319, 0.319, 1), fill_bool, (0.319, 0.319, 0.319, 1))
        gp_data.materials.append(gp_mat)
        gp_mat = make_gp_mat("Grey Lightest", stroke_bool, (0.515,
                                                            0.515, 0.515, 1), fill_bool, (0.515, 0.515, 0.515, 1))
        gp_data.materials.append(gp_mat)
    if preferences.mat_wht_bool:
        stroke_bool = True
        fill_bool = False
        gp_mat = make_gp_mat(
            "White", stroke_bool, (1.0, 1.0, 1.0, 1), fill_bool, (1.0, 1.0, 1.0, 1))
        gp_data.materials.append(gp_mat)
    if preferences.mat_fav_bool:
        gpnam = preferences.mat_fav_name
        strkb = preferences.mat_fav_stkbool
        strkc = preferences.mat_fav_stkcolor
        fillb = preferences.mat_fav_fillbool
        fillc = preferences.mat_fav_fillcolor
        # make_gp_mat(colorname, s_bool, s_rgba, f_bool, f_rgba)
        gp_mat = make_gp_mat(gpnam, strkb, strkc, fillb, fillc)
        gp_data.materials.append(gp_mat)
    if preferences.mat_fav1_bool:
        gpnam = preferences.mat_fav1_name
        strkb = preferences.mat_fav1_stkbool
        strkc = preferences.mat_fav1_stkcolor
        fillb = preferences.mat_fav1_fillbool
        fillc = preferences.mat_fav1_fillcolor
        gp_mat = make_gp_mat(gpnam, strkb, strkc, fillb, fillc)
        gp_data.materials.append(gp_mat)
    if preferences.mat_fav2_bool:
        gpnam = preferences.mat_fav2_name
        strkb = preferences.mat_fav2_stkbool
        strkc = preferences.mat_fav2_stkcolor
        fillb = preferences.mat_fav2_fillbool
        fillc = preferences.mat_fav2_fillcolor
        gp_mat = make_gp_mat(gpnam, strkb, strkc, fillb, fillc)
        gp_data.materials.append(gp_mat)
    if preferences.mat_fav3_bool:
        gpnam = preferences.mat_fav3_name
        strkb = preferences.mat_fav3_stkbool
        strkc = preferences.mat_fav3_stkcolor
        fillb = preferences.mat_fav3_fillbool
        fillc = preferences.mat_fav3_fillcolor
        gp_mat = make_gp_mat(gpnam, strkb, strkc, fillb, fillc)
        gp_data.materials.append(gp_mat)
    # Draw, using the material defined
    bpy.ops.gpencil.draw(wait_for_input=False)
    # Assign the material to the grease pencil for drawing
    bpy.context.object.active_material_index = 0
    # Choose grease pencil layer
    # gpl_active = bpy.context.active_object.data.layers.active.info
    gpl_choices = bpy.context.active_object.data.layers.items()
    for g, gpl in enumerate(gpl_choices):
        if gp_layer == gpl[0]:
            bpy.context.active_object.data.layers.active_index = g
            break
    bpy.context.space_data.show_region_tool_header = True


def convert283_board():
    """Converts to a Grease Pencil object."""
    bpy.ops.object.convert(target='CURVE', keep_original=True)
    bpy.ops.object.convert(target='GPENCIL')


def convert290_board():
    """Converts to a Grease Pencil object."""
    bpy.ops.object.convert(target='GPENCIL', keep_original=True, thickness=3)


def find_spacetime(context):
    # find location and time for new panels

    curscene = bpy.context.scene.name
    scene = bpy.data.scenes[curscene]
    curframe = bpy.data.scenes[curscene].frame_current
    storyboard = bpy.context.scene.sb_data
    shot_count = storyboard.shots
    timeframe = 1
    time_jump = 20
    cams = []
    mlist = []
    markerlist = []
    camframes = []

    cursor_loc = bpy.context.scene.cursor.location
    loc_x = cursor_loc[0]
    loc_z = cursor_loc[2]

    if shot_count == 1:
        loc_x = 3.52
        loc_z = 0
        timeframe = 21
    else:
        xmax = 0
        mlist = scene.timeline_markers
        markerlist = sorted(mlist, key=lambda mlist: mlist.frame)
        for m in markerlist:
            if m.camera:
                cam_x = m.camera.location[0]
                if cam_x > xmax:
                    xmax = cam_x
                cams.append(m.camera)
                camframes.append(m.frame)
        timeframe = camframes[-1] + (camframes[-1] - camframes[-2])

        if len(cams) > 1:
            x1 = cams[-1].location[0]
            x2 = cams[-2].location[0]
            z1 = cams[-1].location[2]
            z2 = cams[-2].location[2]
            print("x1", x1)
            print("xmax", xmax)
            if (z1 == 0):
                loc_x = x1 + (x1 - x2)
                loc_z = 0
            elif (z1 == z2) and (x1 > x2) and not (x1 > int(xmax)):
                # same line
                loc_x = x1 + (x1 - x2)
                loc_z = z1
            elif (x1 == 0) and (x2 > 0):
                # second of new line
                loc_x = 3.52
                loc_z = z1
            else:
                # new line
                loc_x = 0
                loc_z = z1 - 3.24

    return (loc_x, loc_z, timeframe)


def add_board(loc_x, loc_z, timeframe):
    """Makes a new board at the XZ location and adds a marker at timeframe."""
    # get name of current scene
    curscene = bpy.context.scene.name
    scene = bpy.data.scenes[curscene]
    storyboard = bpy.context.scene.sb_data
    preferences = bpy.context.preferences.addons[__package__].preferences
    # update number of shots
    shot_count = storyboard.shots
    shot_count += 1
    storyboard.shots = shot_count
    # store current collection name
    prev_collection = bpy.context.view_layer.active_layer_collection
    # make Storyboard_Panels collection active
    select_collection('Storyboard_Panels')
    # add a plane object at the 3D cursor
    bpy.ops.mesh.primitive_plane_add(
        size=1, enter_editmode=False)
    obj = bpy.context.object
    # obj.name = "board.001"  # CHANGE name
    obj.name = "board." + str(shot_count).zfill(3)
    obj.location[0] = loc_x
    obj.location[1] = 0.2
    obj.location[2] = loc_z
    cursor = bpy.context.scene.cursor
    cursor.location = obj.location
    cursor.location[1] = 0
    bpy.context.object.rotation_euler[0] = 1.5708  # radians for 90 degrees
    obj.scale[0] = 3.2
    obj.scale[1] = 1.8
    bpy.ops.object.select_all(action='DESELECT')
    # make Storyboard_Cameras collection active
    select_collection('Storyboard_Cameras')
    # add a camera and offset it from the plane
    bpy.ops.object.camera_add(rotation=(1.5708, 0, 0))
    bpy.context.object.data.type = 'ORTHO'
    bpy.context.object.data.ortho_scale = 3.2
    shotcam = bpy.context.active_object
    shotcam.location[0] = loc_x
    shotcam.location[1] = -15.6431
    shotcam.location[2] = loc_z
    bsname = storyboard.basename
    shotcam.name = bsname + " " + str(shot_count)
    shotcam.data.name = shotcam.name
    bpy.context.scene.camera = shotcam
    # Add board to camera elements
    elem = shotcam.data.sb_objects.add()
    elem.name = obj.name
    elem.obj = obj
    # Create new text file
    bpy.ops.text.new()
    # Rename text file
    bpy.data.texts['Text'].name = shotcam.name
    # add a marker at the current time
    curframe = timeframe
    mark_name = "m_" + str(curframe)
    marker = scene.timeline_markers.new(mark_name, frame=curframe)
    # bind camera to marker
    marker.camera = shotcam
    # add Grease Pencil basic here

    bpy.ops.object.select_all(action='DESELECT')
    obj.select_set(True)
    bpy.context.view_layer.objects.active = obj
    # restore previous collection
    select_collection(prev_collection.name)


def create_boards(self, context):
    """Creates the array of objects for each plane"""

    print("Quickstart STORYBOARD_OT_creation")

    shot_list = []  # List for storing boards and cameras
    sbloc = (0, 0, 0)

    #       Make this new start after user has chosen parameters
    horizontal = bpy.data.objects["board.001"].modifiers["Array"].count
    vertical = bpy.data.objects["board.001"].modifiers["Array.001"].count
    storyboard = bpy.context.scene.sb_data
    storyboard.shots = horizontal * vertical
    storyboard.created = True
    storyboard.cam_views = 'STORYBOARD'
    #        bpy.context.scene.storyboard_basename = self.basename
    #        bpy.context.scene.storyboard_basename = storyboard.basename
    # Blender 2.8
    # bpy.ops.object.modifier_apply(apply_as='DATA', modifier="Array")
    # bpy.ops.object.modifier_apply(apply_as='DATA', modifier="Array.001")
    # Blender 2. TEST
    bpy.ops.object.modifier_apply(modifier="Array")
    bpy.ops.object.modifier_apply(modifier="Array.001")

    # Separate object into individual planes
    bpy.ops.object.editmode_toggle()
    bpy.ops.mesh.select_all(action='SELECT')
    bpy.ops.mesh.separate(type='LOOSE')
    bpy.ops.object.editmode_toggle()
    # Set origins to geometry center
    bpy.ops.object.origin_set(type='ORIGIN_GEOMETRY')
    boards = context.selected_objects
    cursor = bpy.context.scene.cursor

    # Create Storyboard camera
    select_collection('Storyboard')
    bpy.ops.object.camera_add(rotation=(1.5708, 0, 0))
    sbcam = bpy.context.active_object
    sbcam.data.name = "Storyboard"
    sbcam.name = "Storyboard"
    curframe = -20
    curscene = bpy.context.scene.name
    scene = bpy.data.scenes[curscene]
    mark_name = "M_0"
    marker = scene.timeline_markers.new(mark_name, frame=curframe)
    marker.camera = bpy.data.objects['Storyboard']

    # Add cameras
    select_collection('Storyboard_Cameras')
    # makeboard_collection('Storyboard_Cameras')
    # boards = context.selected_objects
    # cursor = bpy.context.scene.cursor
    for ob in boards:
        bpy.ops.object.select_all(
            action='DESELECT')  # Deselect all objects
        bpy.context.view_layer.objects.active = ob   # Make the board the active object
        ob.select_set(True)                          # Select the object
        act_obj = bpy.context.active_object
        cursor.location = act_obj.location
        sbloc = cursor.location
        self.shot_count += 1
        #            cam_name = self.basename + " " + str(self.shot_count)
        cam_name = storyboard.basename + " " + str(self.shot_count)
        bpy.ops.object.camera_add(rotation=(1.5708, 0, 0))
        new_cam = bpy.context.active_object
        elem = new_cam.data.sb_objects.add()
        elem.name = ob.name
        elem.obj = ob
        # elem = new_cam.data.sb_objects.add()
        # elem.data = ob.data.name
        bpy.context.object.data.type = 'ORTHO'
        bpy.context.object.data.ortho_scale = 3.2
        shotcam = bpy.context.active_object
        shotcam.name = cam_name
        new_cam.data.name = cam_name
        if not self.first_cam:
            self.first_cam = True
            self.firstcam_name = cam_name

        shotcam.location[1] = -15.6431
        shot_list.append(cam_name)  # Add name to shot list

    # Update Storyboard camera
    #        makeboard_collection('Storyboard')
    select_collection('Storyboard')
    x, y, z = sbloc
    ortho_h = horizontal * 3.5
    ortho_v = vertical * 5.8
    ortho_scale = ortho_h if ortho_h > ortho_v else ortho_v
    #        bpy.ops.object.camera_add(rotation=(1.5708, 0, 0))
    #        sbcam = bpy.context.active_object
    sbcam.data.type = 'ORTHO'
    sbcam.data.ortho_scale = ortho_scale
    sbcam.location = ((x / 2), -16, (z / 2))
    #        sbcam.data.name = "Storyboard"
    #        sbcam.name = "Storyboard"

    # Add markers and bind cameras
    curframe = 1
    marker_count = 0
    curscene = bpy.context.scene.name
    scene = bpy.data.scenes[curscene]

    for mk in shot_list:
        marker_count += 1
        thecam = bpy.data.objects.get(mk)
        mark_name = "M_" + str(marker_count)
        marker = scene.timeline_markers.new(mark_name, frame=curframe)
        marker.camera = thecam
        bpy.ops.text.new()  # Create new text file
        bpy.data.texts['Text'].name = mk    # Rename text file
        curframe += self.time_jump

    bpy.types.Scene.storyboard_count = marker_count

    bpy.ops.object.select_all(action='DESELECT')
    bpy.context.scene.frame_current = 1
    firstcam = bpy.context.scene.objects[self.firstcam_name]
    bpy.context.scene.camera = firstcam
    firstcam.select_set(True)
    bpy.context.view_layer.objects.active = firstcam

    # Show correct text page in Text Editor
    update_text_editor()

    # Stop here for board creation
    bpy.context.scene.cursor.location = (0, 0, 0)

    # restore previos active collection
    select_collection(storyboard.original_collection)


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@

class STORYBOARD_OT_creation(Operator):
    """Make panels starting at 3d cursor"""
    bl_label = "Create Storyboard Panels"
    bl_idname = 'boards.creation'
    bl_description = "Make panels starting at 3d cursor"

    basename: bpy.props.StringProperty(name="Base Name", default="shot")
    cam_name: bpy.props.StringProperty(name="Camera Name")
    shot_count: bpy.props.IntProperty(default=0)
    first_cam: bpy.props.BoolProperty(default=False)
    firstcam_name: bpy.props.StringProperty()
    x_offset: bpy.props.FloatProperty(default=1.0)
    y_offset: bpy.props.FloatProperty(default=-1.1)

    board_x: bpy.props.IntProperty(
        name="Horizontal (X)",
        description="Number of Horizontal panels in the X-direction",
        default=4,
        min=1, soft_max=10,
    )

    board_y: bpy.props.IntProperty(
        name="Vertical (Y)",
        description="Number of Vertical panels in the Y-direction",
        default=3,
        min=1, soft_max=10,
    )

    board_spacing: bpy.props.FloatProperty(
        name="Spacing",
        description="Space between panels",
        default=0.1,
        min=0.0, soft_max=1.0,
    )

    vert_spacing: bpy.props.FloatProperty(
        name="Spacing",
        description="Vertical space between panels",
        default=-1.1,
        soft_min=-2.0, soft_max=-1.0,
    )

    make_materials: bpy.props.BoolProperty(
        name="Make Materials",
        description="Create materials for each panel",
        default=False,
    )

    make_texts: bpy.props.BoolProperty(
        name="Use Text Editor",
        description="Create Text Editor data blocks for each panel",
        default=True,
    )

    time_jump: bpy.props.IntProperty(
        name="Time Jump",
        description="Number of frames between markers",
        default=20,
        min=1,
    )

    delete_cube: bpy.props.BoolProperty(
        name="Delete Cube",
        description="Delete the default cube",
        default=True,
    )

    def execute(self, context):
        # print("STORYBOARD_OT_creation")
        if self.delete_cube:
            try:
                if bpy.data.objects['Cube']:
                    bpy.ops.object.select_all(action='DESELECT')
                    bpy.data.objects['Cube'].select_set(True)
                    bpy.ops.object.delete()
            except:
                pass

        shot_list = []  # List for storing boards and cameras
        sbloc = (0, 0, 0)

        #       Make this new start after user has chosen parameters
        bpy.data.objects['board.001'].select_set(True)
        horizontal = bpy.data.objects["board.001"].modifiers["Array"].count
        vertical = bpy.data.objects["board.001"].modifiers["Array.001"].count
        storyboard = bpy.context.scene.sb_data
        storyboard.shots = horizontal * vertical
        storyboard.created = True
        storyboard.cam_views = 'STORYBOARD'
        #        bpy.context.scene.storyboard_basename = self.basename
        #        bpy.context.scene.storyboard_basename = storyboard.basename
        bpy.ops.object.modifier_apply(modifier="Array")
        bpy.ops.object.modifier_apply(modifier="Array.001")

        # Separate object into individual planes
        bpy.ops.object.editmode_toggle()
        bpy.ops.mesh.select_all(action='SELECT')
        bpy.ops.mesh.separate(type='LOOSE')
        bpy.ops.object.editmode_toggle()
        # Set origins to geometry center
        bpy.ops.object.origin_set(type='ORIGIN_GEOMETRY')
        boards = context.selected_objects
        cursor = bpy.context.scene.cursor

        # Create Storyboard camera
        select_collection('Storyboard')
        bpy.ops.object.camera_add(rotation=(1.5708, 0, 0))
        sbcam = bpy.context.active_object
        sbcam.hide_set(True)
        sbcam.data.name = "Storyboard"
        sbcam.name = "Storyboard"

        # Create Sun Light
        bpy.ops.object.light_add(type='SUN', radius=1,
                                 align='WORLD', rotation=(1.5708, 0, 0))
        sunny = bpy.context.active_object
        sunny.hide_set(True)
        sunny.data.use_shadow = False
        sunny.data.name = "Storyboard Light"
        sunny.name = "Storyboard Light"

        # Add cameras
        select_collection('Storyboard_Cameras')
        # makeboard_collection('Storyboard_Cameras')
        # boards = context.selected_objects
        # cursor = bpy.context.scene.cursor
        for ob in boards:
            bpy.ops.object.select_all(action='DESELECT')
            bpy.context.view_layer.objects.active = ob   # Make the board the active object
            ob.select_set(True)                          # Select the object
            act_obj = bpy.context.active_object
            cursor.location = act_obj.location
            sbloc = cursor.location
            self.shot_count += 1
            #            cam_name = self.basename + " " + str(self.shot_count)
            cam_name = storyboard.basename + " " + str(self.shot_count)
            bpy.ops.object.camera_add(rotation=(1.5708, 0, 0))
            new_cam = bpy.context.active_object
            elem = new_cam.data.sb_objects.add()
            elem.name = ob.name
            elem.obj = ob
            # elem = new_cam.data.sb_objects.add()
            # elem.data = ob.data.name
            bpy.context.object.data.type = 'ORTHO'
            bpy.context.object.data.ortho_scale = 3.2
            shotcam = bpy.context.active_object
            shotcam.name = cam_name
            shotcam.data.name = cam_name
            if not self.first_cam:
                self.first_cam = True
                self.firstcam_name = cam_name

            shotcam.location[1] = -15.6431
            shot_list.append(cam_name)  # Add name to shot list

        # Update Storyboard camera
        #        makeboard_collection('Storyboard')
        select_collection('Storyboard')
        x, y, z = sbloc
        ortho_h = horizontal * 3.5
        ortho_v = vertical * 5.8
        ortho_scale = ortho_h if ortho_h > ortho_v else ortho_v
        #        bpy.ops.object.camera_add(rotation=(1.5708, 0, 0))
        #        sbcam = bpy.context.active_object
        sbcam.data.type = 'ORTHO'
        sbcam.data.ortho_scale = ortho_scale
        sbcam.location = ((x / 2), -16, (z / 2))
        sunny.location = sbcam.location
        sunny.location[1] = -17

        # Add storyboard camera to list of views
        scn = bpy.context.scene
        item = scn.sb_camviews.add()
        scn.sb_cvindex = len(scn.sb_camviews)-1
        if storyboard.shots > 1:
            item.name = "%s 1-%s" % (storyboard.basename, str(storyboard.shots))
        else:
            item.name = "%s 1" % (storyboard.basename)
        item.cam_pos = sbcam.location
        item.ortho_scale = sbcam.data.ortho_scale

        # Add markers and bind cameras
        curframe = 1
        marker_count = 0
        curscene = bpy.context.scene.name
        scene = bpy.data.scenes[curscene]

        for mk in shot_list:
            marker_count += 1
            thecam = bpy.data.objects.get(mk)
            mark_name = "M_" + str(marker_count)
            marker = scene.timeline_markers.new(mark_name, frame=curframe)
            marker.camera = thecam
            bpy.ops.text.new()  # Create new text file
            bpy.data.texts['Text'].name = mk    # Rename text file
            curframe += self.time_jump

        bpy.types.Scene.storyboard_count = marker_count

        bpy.ops.object.select_all(action='DESELECT')
        bpy.context.scene.frame_current = 1
        firstcam = bpy.context.scene.objects[self.firstcam_name]
        bpy.context.scene.camera = firstcam
        firstcam.select_set(True)
        bpy.context.view_layer.objects.active = firstcam

        # bpy.data.objects['Storyboard'].select_set(True)
        # bpy.context.view_layer.objects.active = bpy.data.objects['Storyboard']
        # bpy.context.scene.camera = bpy.data.objects['Storyboard']
        # Eventually set pref to see shot 1 camera first or Storyboard camera
        # bpy.context.scene.frame_current = 1

        # Show correct text page in Text Editor
        update_text_editor()

        # Stop here for board creation
        bpy.context.scene.cursor.location = (0, 0, 0)

        # restore previos active collection
        select_collection(storyboard.original_collection)

        return {'FINISHED'}

    def draw(self, context):

        layout = self.layout
        scene = context.scene
        storyboard = bpy.context.scene.sb_data
        preferences = bpy.context.preferences.addons[__package__].preferences

        row = layout.row()
        #        row.label(self, " ")
        #        row.prop(self, "basename")
        row.prop(storyboard, "basename")

        box = layout.box()
        row = box.row()
        row.label(text="Horizontal")
        row.prop(bpy.data.objects["board.001"].modifiers["Array"], 'count')

        row = box.row()
        row.label(text="Vertical")
        row.prop(
            bpy.data.objects["board.001"].modifiers["Array.001"], 'count')

        brd_columns = bpy.data.objects["board.001"].modifiers["Array"].count
        brd_rows = bpy.data.objects["board.001"].modifiers["Array.001"].count
        sum_boards = (brd_columns * brd_rows)
        #        storyboard.shots = sum_boards

        total_boards = "Number of panels: " + str(sum_boards)

        row = box.row()
        row.alignment = 'RIGHT'
        row.label(text=total_boards)

        #        layout.prop(self, "board_spacing")
        #    vert_array = bpy.data.objects["board.001"].modifiers["Array.001"]
        #        layout.prop(vert_array, 'relative_offset_displace[1]')
        #        layout.prop(self, "make_materials")
        #        layout.prop(self, "make_texts")
        layout.row().separator()

        box = layout.box()
        row = box.row()
        row.label(text='Animatic')
        #        row.prop(bpy.context.scene, 'animatic')
        #        if bpy.context.scene.animatic:
        row.prop(self, "time_jump")
        try:
            if bpy.data.objects['Cube']:
                box = layout.box()
                row = box.row()
                row.label(text='Scene')
                row.prop(self, "delete_cube")
        except:
            pass

    def invoke(self, context, event):
        #        prev_collection = bpy.context.view_layer.active_layer_collection
        scene = bpy.context.scene
        storyboard = bpy.context.scene.sb_data
        preferences = bpy.context.preferences.addons[__package__].preferences
        storyboard.basename = preferences.main_camera_names
        if preferences.gplayer_fav2_fave:
            storyboard.fastdraw_layer = preferences.gplayer_fav2_name
        if preferences.gplayer_fav4_fave:
            storyboard.fastdraw_layer = preferences.gplayer_fav4_name
        store_prevcollection(self)
        makeboard_collection('Storyboard')
        makeboard_collection('Storyboard_Cameras')
        makeboard_collection('Storyboard_Elements')
        makeboard_collection('Storyboard_Panels')
        bpy.ops.mesh.primitive_plane_add(
            size=1, enter_editmode=False, location=(0, 0.1, 0))
        obj = bpy.context.object
        obj.name = "board.001"
        bpy.context.object.rotation_euler[0] = 1.5708  # radians for 90 degrees
        obj.scale[0] = 3.2
        obj.scale[1] = 1.8
        #        basename = bpy.context.scene.storyboard_basename
        #        basename = storyboard.basename
        #        print(basename)
        x_space = self.x_offset + self.board_spacing
        bpy.ops.object.modifier_add(type='ARRAY')
        # bpy.data.objects[obj.name].modifiers["Array"].count = scene.storyboard_columns
        bpy.data.objects[obj.name].modifiers["Array"].count = preferences.columns
        #        obj.modifiers["Array"].relative_offset_displace[0] = self.board_spacing
        obj.modifiers["Array"].relative_offset_displace[0] = x_space

        y_space = self.y_offset - self.board_spacing
        bpy.ops.object.modifier_add(type='ARRAY')
        # bpy.context.object.modifiers["Array.001"].count = bpy.context.scene.storyboard_rows
        board_rows = preferences.rows
        if preferences.boardstyle == 'STRIP':
            board_rows = 1
        bpy.context.object.modifiers["Array.001"].count = board_rows
        bpy.context.object.modifiers["Array.001"].relative_offset_displace[0] = 0
        #        bpy.context.object.modifiers["Array.001"].relative_offset_displace[1] = y_space
        #        bpy.context.object.modifiers["Array.001"].relative_offset_displace[1] = bpy.context.scene.sb_data.verticalspace
        bpy.context.object.modifiers["Array.001"].relative_offset_displace[1] = storyboard.verticalspace
        if preferences.quickstart:
            try:
                if bpy.data.objects['Cube']:
                    bpy.ops.object.select_all(action='DESELECT')
                    bpy.data.objects['Cube'].select_set(True)
                    bpy.ops.object.delete()
            except:
                pass
            create_boards(self, context)
            return {'FINISHED'}
        else:
            return context.window_manager.invoke_props_dialog(self)

# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@


class STORYBOARD_OT_find(Operator):
    bl_label = "Pick Camera by Element"
    bl_idname = 'boards.find'
    bl_description = "Pick camera by finding object in camera list"

    def execute(self, context):
        if bpy.context.active_object.type == 'CAMERA':
            bpy.context.scene.camera = bpy.context.active_object
        cameras = [o for o in bpy.context.scene.objects if o.type == 'CAMERA']
        obj = bpy.context.selected_objects
        if obj and cameras:
            cur = bpy.context.selected_objects[0]
            for cam in cameras:
                if cur.name in cam.data.sb_objects:
                    bpy.context.scene.camera = cam
                    return {'FINISHED'}

        return {'FINISHED'}


class STORYBOARD_OT_addelement(Operator):
    bl_idname = 'boards.addelement'
    bl_label = "Assign to Camera"
    bl_description = "Add objects to camera list"

    def execute(self, context):
        cam = bpy.context.scene.camera
        if not cam:
            return {'CANCELLED'}
        cur = bpy.context.selected_objects
        if len(cur) > 0:
            for c in cur:
                if not c.type == 'CAMERA':
                    elem = cam.data.sb_objects.add()
                    elem.name = c.name
                    elem.obj = c

        return {'FINISHED'}


class STORYBOARD_OT_pickelement(Operator):
    """Select object in current shot"""
    bl_idname = "boards.pickelement"
    bl_label = "Pick Camera Element"
    bl_description = "Select object in current shot"

    def execute(self, context):
        elem = context.object
        obj = elem.obj
        cam = bpy.context.scene.camera
        if context.active_object:
            bpy.ops.object.mode_set(mode='OBJECT')
            bpy.ops.object.select_all(action='DESELECT')
        if not obj.visible_get():
            obj.hide_set(False)
        try:
            bpy.context.view_layer.objects.active = obj
        except:
            elemid = cam.data.sb_objects.find(obj.name)
            if elemid >= 0:
                cam.data.sb_objects.remove(elemid)
            else:
                elemid = cam.data.sb_objects.find(obj.data.name)
                if elemid >= 0:
                    cam.data.sb_objects.remove(elemid)
            ShowMessageBox("Removed Object from List", "Object Missing", 'INFO')
            return {'CANCELLED'}
        if obj.type and obj.type == 'GPENCIL':
            bpy.ops.object.mode_set(mode='PAINT_GPENCIL')
        else:
            bpy.ops.object.mode_set(mode='OBJECT')
            bpy.ops.object.select_all(action='DESELECT')
        obj.select_set(True)
        bpy.context.view_layer.objects.active = obj

        return {'FINISHED'}


class STORYBOARD_OT_pickallelements(Operator):
    """Select all objects in current shot"""
    bl_idname = "boards.pickallelements"
    bl_label = "Pick All Camera Elements"
    bl_description = "Select all objects in current shot"

    def execute(self, context):
        cam = bpy.context.scene.camera
        if cam:
            if len(bpy.context.selected_objects):
                bpy.ops.object.mode_set(mode='OBJECT')
            bpy.ops.object.select_all(action='DESELECT')
            for o in cam.data.sb_objects:
                if not o.obj.visible_get():
                    o.obj.hide_set(False)
                o.obj.select_set(True)
            cam.select_set(True)
            bpy.context.view_layer.objects.active = cam

        return {'FINISHED'}


class STORYBOARD_OT_unlinkelement(Operator):
    """Remove link from object to camera"""
    bl_idname = "boards.unlinkelement"
    bl_label = "Unassign Camera Element"
    bl_description = "Unlink object from camera"

    def execute(self, context):
        elem = context.object
        obj = elem.obj
        cam = bpy.context.scene.camera
        elemid = cam.data.sb_objects.find(obj.name)
        if elemid >= 0:
            cam.data.sb_objects.remove(elemid)
        else:
            elemid = cam.data.sb_objects.find(obj.data.name)
            if elemid >= 0:
                cam.data.sb_objects.remove(elemid)
        bpy.ops.object.select_all(action='DESELECT')

        return {'FINISHED'}


class STORYBOARD_OT_fastdraw(Operator):
    """Activate or add a Grease Pencil Oject in current shot"""
    bl_label = "Fast Draw"
    bl_idname = 'boards.fastdraw'
    bl_description = "Activate or add a Grease Pencil Oject in current shot"

    def execute(self, context):

        storyboard = bpy.context.scene.sb_data
        gpexists = False
        gpobj = None
        gp_layer = storyboard.fastdraw_layer
        cam = bpy.context.scene.camera
        obj = bpy.context.active_object
        if not (2, 93, 0) > bpy.app.version:
            bpy.context.scene.tool_settings.use_keyframe_insert_auto = True
        if obj:
            if obj.type == 'GPENCIL':
                gp_layer = bpy.context.active_object.data.layers.active.info
                storyboard.fastdraw_layer = gp_layer
                # if not gp_layer == storyboard.fastdraw_layer:
                #     storyboard.fastdraw_layer = gp_layer

        if cam:
            for elem in cam.data.sb_objects:
                if not (elem.obj.type == 'GPENCIL'):
                    continue
                else:
                    if not gpexists:
                        gpexists = True
                        gpobj = elem.obj
                if not obj:
                    break
                if (obj.name == elem.obj.name) and (elem.obj.type == 'GPENCIL'):
                    gpobj = elem.obj
                    break
            if gpexists:
                if obj:
                    bpy.ops.object.mode_set(mode='OBJECT')
                bpy.ops.object.select_all(action='DESELECT')
                gpobj.select_set(True)
                bpy.context.view_layer.objects.active = gpobj
                bpy.ops.object.mode_set(mode='PAINT_GPENCIL')
            else:
                fastgpdraw(gp_layer)

        return {'FINISHED'}


class STORYBOARD_OT_stopdraw(Operator):
    """Exit out of Draw and go into Object Mode"""
    bl_label = "Stop Draw"
    bl_idname = 'boards.stopdraw'
    bl_description = "Exit out of Draw and go into Object Mode"

    def execute(self, context):

        storyboard = bpy.context.scene.sb_data
        cam = bpy.context.scene.camera
        obj = bpy.context.active_object
        if not (2, 93, 0) > bpy.app.version:
            bpy.context.scene.tool_settings.use_keyframe_insert_auto = False
        if obj:
            if obj.type == 'GPENCIL':
                gp_layer = bpy.context.active_object.data.layers.active.info
                storyboard.fastdraw_layer = gp_layer
            bpy.ops.object.mode_set(mode='OBJECT')

        return {'FINISHED'}


# ================================================================================


class STORYBOARD_OT_camprev(Operator):
    """Activate previous camera in scene"""
    bl_label = "Marker Nav"
    bl_idname = 'boards.camprev'

    def execute(self, context):

        gpexists = False
        gpobj = None
        obj = bpy.context.active_object
        storyboard = bpy.context.scene.sb_data
        if obj:
            if obj.type == 'GPENCIL':
                storyboard.fastdraw_layer = bpy.context.active_object.data.layers.active.info

        select_prev_cam(context)
        update_text_editor()

        if storyboard.created and storyboard.fast_draw:
            cam = bpy.context.scene.camera
            if cam:
                if obj:
                    for elem in cam.data.sb_objects:
                        if not (elem.obj.type == 'GPENCIL'):
                            continue
                        else:
                            if not gpexists:
                                gpexists = True
                                gpobj = elem.obj
                        if (obj.name == elem.obj.name) and (elem.obj.type == 'GPENCIL'):
                            gpobj = elem.obj
                            break
                if gpexists:
                    bpy.ops.object.mode_set(mode='OBJECT')
                    bpy.ops.object.select_all(action='DESELECT')
                    gpobj.select_set(True)
                    bpy.context.view_layer.objects.active = gpobj
                    bpy.ops.object.mode_set(mode='PAINT_GPENCIL')
                else:
                    fastgpdraw(storyboard.fastdraw_layer)

        return {'FINISHED'}


class STORYBOARD_OT_camnext(Operator):
    """Activate next camera in scene"""
    bl_label = "Marker Nav"
    bl_idname = 'boards.camnext'

    def execute(self, context):

        obj = bpy.context.active_object
        storyboard = bpy.context.scene.sb_data
        if storyboard.created and storyboard.fast_draw:
            if obj:
                if obj.type == 'GPENCIL':
                    storyboard.fastdraw_layer = bpy.context.active_object.data.layers.active.info

            # check for last camera
            cameras = []
            mlist = context.scene.timeline_markers
            markerlist = sorted(mlist, key=lambda mlist: mlist.frame)
            for m in markerlist:
                if m.camera:
                    cameras.append(m.camera)
            if len(cameras) > 0:
                curcam = bpy.context.scene.camera
                if curcam.name == cameras[-1].name:
                    # confirmed at last
                    placetime = find_spacetime(context)
                    add_board(placetime[0], placetime[1], placetime[2])
                    fastgpdraw(storyboard.fastdraw_layer)
                else:
                    # go to next camera and draw
                    gpexists = False
                    gpobj = None
                    obj = bpy.context.active_object

                    select_next_cam(context)
                    update_text_editor()

                    cam = bpy.context.scene.camera
                    if cam:
                        for elem in cam.data.sb_objects:
                            if not (elem.obj.type == 'GPENCIL'):
                                continue
                            else:
                                if not gpexists:
                                    gpexists = True
                                    gpobj = elem.obj
                            if obj:
                                if (obj.name == elem.obj.name) and (elem.obj.type == 'GPENCIL'):
                                    gpobj = elem.obj
                                    break
                        if gpexists:
                            if obj:
                                bpy.ops.object.mode_set(mode='OBJECT')
                            bpy.ops.object.select_all(action='DESELECT')
                            gpobj.select_set(True)
                            bpy.context.view_layer.objects.active = gpobj
                            bpy.ops.object.mode_set(mode='PAINT_GPENCIL')
                        else:
                            fastgpdraw(storyboard.fastdraw_layer)
                    return {'FINISHED'}
        else:
            select_next_cam(context)
            update_text_editor()

        return {'FINISHED'}


# ================================================================================

class STORYBOARD_OT_rearrange(Operator):
    """Change the layout of the storyboard"""
    bl_label = "Change Layout"
    bl_idname = 'storyboard.rearrange'

    col_x: bpy.props.IntProperty(
        name="Columns",
        description="Number of columns",
        default=4,
        min=1,
        max=100,
    )
    x_offset: bpy.props.FloatProperty(
        name="X Offset",
        description="Horizontal space between boards",
        default=3.52,
        soft_min=3.2,
        min=0.01,
    )
    z_offset: bpy.props.FloatProperty(
        name="Z Offset",
        description="Vertical space between boards",
        default=3.24,
        soft_min=1.8,
        min=0.01,
    )

    def execute(self, context):
        # curscene = bpy.context.scene.name
        x_horizontal = []
        z_vertical = []
        cameras = []
        mlist = context.scene.timeline_markers
        markerlist = sorted(mlist, key=lambda mlist: mlist.frame)
        for m in markerlist:
            if m.camera:
                cameras.append(m.camera)
        len_cams = len(cameras)
        if len_cams > 0:
            row_z = math.ceil(len_cams / self.col_x)
            # Build array of positions
            for z in range(row_z):
                for x in range(self.col_x):
                    x_horizontal.append(round((x * self.x_offset), 2))
                    z_vertical.append(round((-1 * z * self.z_offset), 2))
            # Move elements and cameras
            for c, cam in enumerate(cameras):
                for o in cam.data.sb_objects:
                    x_diff = x_horizontal[c] - cam.location[0]
                    o.obj.location[0] += x_diff
                    # o.obj.location[0] = x_horizontal[c]
                    z_diff = z_vertical[c] - cam.location[2]
                    o.obj.location[2] += z_diff
                    # o.obj.location[2] = z_vertical[c]
                cam.location[0] = x_horizontal[c]
                cam.location[2] = z_vertical[c]

        return {'FINISHED'}

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        sb_data = bpy.context.scene.sb_data
        preferences = bpy.context.preferences.addons[__package__].preferences

        row = layout.row()
        row.label(text="Press ESC to abort")
        box = layout.box()
        row = box.row()
        row.label(text="Columns")
        row.prop(self, 'col_x', text="")
        row = box.row()
        row.label(text="X Offset")
        row.prop(self, 'x_offset', text="")
        row = box.row()
        row.label(text="Z Offset")
        row.prop(self, 'z_offset', text="")

    def invoke(self, context, event):
        scene = bpy.context.scene
        sb_data = bpy.context.scene.sb_data
        preferences = bpy.context.preferences.addons[__package__].preferences
        return context.window_manager.invoke_props_dialog(self)


class STORYBOARD_OT_centerstoryboard(Operator):
    """Center Storyboard camera on selected objects"""
    bl_label = "Center on Selected"
    bl_idname = 'storyboard.centerstoryboard'

    def execute(self, context):
        objvectorsum = Vector()
        for obj in bpy.context.selected_objects:
            objvectorsum += obj.location
        selected = len(bpy.context.selected_objects)
        if selected:
            objcenter = objvectorsum / selected
            bpy.data.objects['Storyboard'].location[0] = objcenter[0]
            bpy.data.objects['Storyboard'].location[2] = objcenter[2]

        return {'FINISHED'}


class STORYBOARD_OT_storyboardviews(Operator):
    """Storyboard camera view actions"""
    bl_label = "Storyboard Views"
    bl_idname = 'storyboard.storyboardviews'
    bl_description = 'Change Storyboard camera view'

    action: bpy.props.EnumProperty(
        items=(
            ('UP', "Up", ""),
            ('DOWN', "Down", ""),
            ('REMOVE', "Remove", ""),
            ('ADD', "Add", ""),
            ('ACTIVATE', "Activate", ""),
            ('PREVIOUS', "Previous", ""),
            ('NEXT', "Next", "")))

    def invoke(self, context, event):
        scn = bpy.context.scene
        idx = scn.sb_cvindex
        storyboard_cam = bpy.data.objects['Storyboard']
        try:
            item = scn.sb_camviews[idx]
        except IndexError:
            pass
        # else:
        if self.action == 'ADD':
            for c in scn.sb_camviews:
                c.cam_active = False
            item = scn.sb_camviews.add()
            scn.sb_cvindex = len(scn.sb_camviews)-1
            item.name = "view %s" % (scn.sb_cvindex)
            item.cam_pos = storyboard_cam.location
            item.ortho_scale = storyboard_cam.data.ortho_scale
            # info = '"%s" added to list' % (item.name)
            # self.report({'INFO'}, info)
        elif self.action == 'REMOVE' and (len(scn.sb_camviews) > 0):
            info = '"%s" removed from list' % (item.name)
            scn.sb_cvindex -= 1
            scn.sb_camviews.remove(idx)
            if scn.sb_cvindex < 0 and (len(scn.sb_camviews) > 0):
                scn.sb_cvindex = 0
            self.report({'INFO'}, info)
        elif self.action == 'UP' and idx >= 1:
            scn.sb_camviews.move(idx, idx-1)
            scn.sb_cvindex -= 1
        elif self.action == 'DOWN' and (idx < len(scn.sb_camviews) - 1):
            if idx > -1:
                scn.sb_camviews.move(idx, idx+1)
                scn.sb_cvindex += 1
        elif self.action == 'ACTIVATE' and idx >= 0:
            storyboard_cam.location = item.cam_pos
            storyboard_cam.data.ortho_scale = item.ortho_scale
            for c in scn.sb_camviews:
                c.cam_active = False
            item.cam_active = True
        elif self.action == 'PREVIOUS' and idx > 0:
            scn.sb_cvindex -= 1
            idx = scn.sb_cvindex
            storyboard_cam.location = scn.sb_camviews[idx].cam_pos
            storyboard_cam.data.ortho_scale = scn.sb_camviews[idx].ortho_scale
            for c in scn.sb_camviews:
                c.cam_active = False
            scn.sb_camviews[idx].cam_active = True
        elif self.action == 'NEXT' and (idx < len(scn.sb_camviews) - 1):
            scn.sb_cvindex += 1
            idx = scn.sb_cvindex
            storyboard_cam.location = scn.sb_camviews[idx].cam_pos
            storyboard_cam.data.ortho_scale = scn.sb_camviews[idx].ortho_scale
            for c in scn.sb_camviews:
                c.cam_active = False
            scn.sb_camviews[idx].cam_active = True

        return {'FINISHED'}


class STORYBOARD_OT_sbviewsmenu(Operator):
    """Control rendering of Storyboard camera views"""
    bl_label = "Swap cameras"
    bl_idname = 'storyboard.sbviewsmenu'
    bl_description = 'Control rendering of Storyboard camera views'

    action: bpy.props.EnumProperty(
        items=(
            ('RENDERALL', "Render All", ""),
            ('HIDEOTHERS', "Hide Others", ""),
            ('TOGGLERENDERS', "Toggle Renders", "")))

    def invoke(self, context, event):
        scn = bpy.context.scene
        idx = scn.sb_cvindex
        storyboard_cam = bpy.data.objects['Storyboard']
        try:
            item = scn.sb_camviews[idx]
        except IndexError:
            pass
        # else:
        if self.action == 'RENDERALL':
            for c in scn.sb_camviews:
                c.cam_render = True
        elif self.action == 'HIDEOTHERS':
            for c in scn.sb_camviews:
                c.cam_render = False
            scn.sb_camviews[idx].cam_render = True      
        elif self.action == 'TOGGLERENDERS':
            for c in scn.sb_camviews:
                if c.cam_render == True:
                    c.cam_render = False
                else:
                    c.cam_render = True

        return {'FINISHED'}


class STORYBOARD_OT_sbcamsave(Operator):
    """Control rendering of Storyboard camera views"""
    bl_label = "Save Scene Resolution"
    bl_idname = 'storyboard.sbcamsave'
    bl_description = 'Save scene render resolution'

    action: bpy.props.EnumProperty(
        items=(
            ('SCENE', "Scene Default", ""),
            ('OPTONE', "Option 1", ""),
            ('OPTTWO', "Option 2", "")))

    def invoke(self, context, event):
    # def execute(self, context):
        scn = bpy.context.scene
        storyboard = bpy.context.scene.sb_data

        if self.action == 'SCENE':
            if not storyboard.scene_res_saved:
                storyboard.optone_res_x = scn.render.resolution_x
                storyboard.optone_res_y = scn.render.resolution_y
                storyboard.opttwo_res_x = scn.render.resolution_x
                storyboard.opttwo_res_y = scn.render.resolution_y

            storyboard.scene_res_x = scn.render.resolution_x
            storyboard.scene_res_y = scn.render.resolution_y
            storyboard.scene_res_saved = True
            
        elif self.action == 'OPTONE':
            storyboard.optone_res_x = scn.render.resolution_x
            storyboard.optone_res_y = scn.render.resolution_y

        elif self.action == 'OPTTWO':
            storyboard.opttwo_res_x = scn.render.resolution_x
            storyboard.opttwo_res_y = scn.render.resolution_y

        return {'FINISHED'}


class STORYBOARD_OT_swapshot(Operator):
    """Swap camera elements"""
    bl_label = "Swap cameras"
    bl_idname = 'boards.swapshot'

    def execute(self, context):
        scene = context.scene
        tempa = []
        tempb = []
        acam = scene.panelSwapACam.data.sb_objects
        bcam = scene.panelSwapBCam.data.sb_objects
        diffbtoa = scene.panelSwapACam.location - scene.panelSwapBCam.location
        diffatob = scene.panelSwapBCam.location - scene.panelSwapACam.location
        if len(acam.items()) > 0:
            for a in acam:
                tempa.append(a.obj)
                a.obj.location += diffatob
            while len(acam.values()) > 0:
                acam.remove(0)
        if len(bcam.items()) > 0:
            for b in bcam:
                tempb.append(b.obj)
                b.obj.location += diffbtoa
            while len(bcam.values()) > 0:
                bcam.remove(0)
        if len(tempa) > 0:
            for b in tempa:
                elem = bcam.add()
                elem.obj = b
                elem.name = b.name
        if len(tempb) > 0:
            for a in tempb:
                elem = acam.add()
                elem.obj = a
                elem.name = a.name

        return {'FINISHED'}


class STORYBOARD_OT_conversion(Operator):
    """Convert a board to a Grease Pencil object"""
    bl_label = "Convert Board to GP"
    bl_idname = 'boards.conversion'

    action: bpy.props.EnumProperty(
        items=(
            ('VER283', "Ver283", ""),
            ('VER290', "Ver290", "")))

    def execute(self, context):
        obj_boards = []
        for obj in bpy.context.selected_objects:
            if obj.type == 'MESH':
                obj_boards.append(obj)
        bpy.ops.object.select_all(action='DESELECT')
        select_collection("Storyboard_Elements")
        for obj in obj_boards:
            bpy.context.view_layer.objects.active = obj
            obj.select_set(True)
            if (self.action == 'VER283'):
                convert283_board()
            if self.action == 'VER290':
                convert290_board()
            obj.hide_set(True)

        return {'FINISHED'}


class STORYBOARD_OT_addition(Operator):
    """Add a plane with camera at the 3D cursor and a marker to the timeline"""
    bl_label = "Add or Insert a Storyboard Panel"
    bl_idname = 'boards.addition'
    # Manual Addition

    def execute(self, context):

        storyboard = bpy.context.scene.sb_data
        curscene = bpy.context.scene.name
        curframe = bpy.data.scenes[curscene].frame_current
        cursor_loc = bpy.context.scene.cursor.location
        loc_x = cursor_loc[0]
        loc_z = cursor_loc[2]

        add_board(loc_x, loc_z, curframe)
        if storyboard.fast_draw:
            fastgpdraw(storyboard.fastdraw_layer)

        return {'FINISHED'}


class STORYBOARD_OT_append(Operator):
    """Add a plane, camera, and a marker after the last board"""
    bl_label = "Append a Storyboard Panel"
    bl_idname = 'boards.append'
    # Automatic Append

    def execute(self, context):

        storyboard = bpy.context.scene.sb_data

        placetime = find_spacetime(context)
        add_board(placetime[0], placetime[1], placetime[2])
        if storyboard.fast_draw:
            fastgpdraw(storyboard.fastdraw_layer)

        return {'FINISHED'}


class STORYBOARD_OT_updatetexteditor(Operator):
    """Change Text Editor content to match current camera"""
    bl_label = "Update Text Editor"
    bl_idname = 'boards.updatetexteditor'

    def execute(self, context):

        update_text_editor()

        return {'FINISHED'}


class STORYBOARD_OT_cursortopanel(Operator):
    """Move 3D cursor to current panel"""
    bl_label = "3D Cursor to Panel"
    bl_idname = 'boards.cursortopanel'

    def execute(self, context):

        cam = bpy.context.scene.camera
        if not cam:
            return {'CANCELLED'}
        vectpos = cam.location
        bpy.context.scene.cursor.location = vectpos
        bpy.context.scene.cursor.location[1] = 0

        return {'FINISHED'}


class STORYBOARD_OT_copytopanel(Operator):
    """Copy Grease Pencil Object to Panel"""
    bl_label = "Copy GP Object"
    bl_idname = 'storyboard.copytopanel'

    def execute(self, context):
        scene = bpy.context.scene
        obj = scene.panelCopyObj
        cam = scene.panelPasteCam
        pickobj = scene.panelCopyObj
        pickcam = scene.panelPasteCam
        # find GP object
        for g in bpy.context.scene.objects:
            if g.data.name == pickobj.name:
                obj = g
                break
        # find camera
        for d in bpy.context.scene.objects:
            print(d.data.name)
            if d.data.name == pickcam.name:
                cam = d
                break
        if not obj:
            return {'CANCELLED'}
        if not cam:
            return {'CANCELLED'}
        # move 3D cursor
        vectpos = cam.location
        scene.cursor.location = vectpos
        scene.cursor.location[1] = 0
        # copy object
        yprev = obj.location[1]
        new_obj = obj.copy()
        new_obj.data = obj.data.copy()
        new_obj.location = vectpos
        new_obj.location[1] = yprev
        new_name = obj.name.split()
        new_obj.name = scene.panelPasteCam.name + " " + new_name[-1]
        new_obj.data.name = new_obj.name
        bpy.data.collections["Storyboard_Elements"].objects.link(new_obj)
        # assign to correct camera
        elem = cam.data.sb_objects.add()
        elem.name = new_obj.name
        elem.obj = new_obj

        return {'FINISHED'}


class STORYBOARD_OT_movetopanel(Operator):
    """Move Grease Pencil Object to Panel"""
    bl_label = "Move GP Object"
    bl_idname = 'storyboard.movetopanel'

    def execute(self, context):
        scene = bpy.context.scene
        obj = scene.panelCopyObj
        cam = scene.panelPasteCam
        pickobj = scene.panelCopyObj
        pickcam = scene.panelPasteCam
        # find GP object
        for g in bpy.context.scene.objects:
            if g.data.name == pickobj.name:
                obj = g
                break
        # find camera
        for d in bpy.context.scene.objects:
            print(d.data.name)
            if d.data.name == pickcam.name:
                cam = d
                break
        if not obj:
            return {'CANCELLED'}
        if not cam:
            return {'CANCELLED'}
        # move 3D cursor
        vectpos = cam.location
        scene.cursor.location = vectpos
        scene.cursor.location[1] = 0
        # move object
        yprev = obj.location[1]
        obj.location = vectpos
        obj.location[1] = yprev
        # remove from previous camera
        cameras = [o for o in bpy.context.scene.objects if o.type == 'CAMERA']
        for pcam in cameras:
            if obj.name in pcam.data.sb_objects:
                elemid = pcam.data.sb_objects.find(obj.name)
                if elemid >= 0:
                    pcam.data.sb_objects.remove(elemid)
                else:
                    elemid = pcam.data.sb_objects.find(obj.data.name)
                    if elemid >= 0:
                        pcam.data.sb_objects.remove(elemid)
        # assign to correct camera
        elem = cam.data.sb_objects.add()
        elem.name = obj.name
        elem.obj = obj

        return {'FINISHED'}


class STORYBOARD_OT_viewshotlist(Operator):
    """View list of shots"""
    bl_label = "View Shot List"
    bl_idname = 'storyboard.viewshotlist'

    def execute(self, context):
        # Nothing

        return {'FINISHED'}

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        mlist = scene.timeline_markers
        sb_data = bpy.context.scene.sb_data
        preferences = bpy.context.preferences.addons[__package__].preferences
        markerlist = sorted(mlist, key=lambda mlist: mlist.frame)
        scene_fps = scene.render.fps
        display_end = False

        row = layout.row()
        row.label(text="Scene FPS: {}".format(scene_fps))
        box = layout.box()
        row = box.row()
        row.label(text="Frame")
        row.label(text="Name")
        row.label(text="Duration")
        len_markers = len(markerlist)
        if len_markers > 0:
            for m, mark in enumerate(markerlist):
                marker_view = True
                img = 'PMARKER_SEL'
                chekbox = 'CHECKBOX_DEHLT'
                if scene.frame_current == mark.frame:
                    img = 'PMARKER_ACT'
                if mark.select:
                    # img = 'PMARKER_ACT'
                    chekbox = 'CHECKBOX_HLT'
                txt = mark.name
                if txt[0:3].lower() == "mus":
                    img = 'FILE_SOUND'
                if txt[0:3].lower() == "act":
                    img = 'ARMATURE_DATA'
                if txt[0:2].lower() == "fx":
                    img = 'SHADERFX'
                if mark.camera:
                    if sb_data.marker_view == 'MARKERS':
                        marker_view = False
                    img = 'OUTLINER_DATA_CAMERA'
                    if scene.frame_current == mark.frame:
                        img = 'VIEW_CAMERA'
                    if mark.select:
                        # img = 'VIEW_CAMERA'
                        chekbox = 'CHECKBOX_HLT'
                    txt = mark.camera.name
                elif sb_data.marker_view == 'CAMERAS':
                    marker_view = False
                if marker_view:
                    row = box.row()
                    if (mark.frame > scene.frame_end) and not display_end:
                        row.label(text="---")
                        row.label(text="---")
                        row.label(text="---")
                        row = box.row()
                        display_end = True
                    row.label(text=str(mark.frame))
                    row.label(text=txt)
                    frames = 0
                    if len_markers > (m + 1):
                        mnext = markerlist[m + 1].frame
                        if mnext > scene.frame_end:
                            frames = scene.frame_end - mark.frame
                        else:
                            frames = mnext - mark.frame
                    else:
                        frames = scene.frame_end - mark.frame
                    duration = round((frames / scene_fps), 2)
                    row.label(text=str(duration))

        else:
            layout.label(text="No markers in current scene")

    def invoke(self, context, event):
        scene = bpy.context.scene
        sb_data = bpy.context.scene.sb_data
        preferences = bpy.context.preferences.addons[__package__].preferences
        return context.window_manager.invoke_props_dialog(self)


class STORYBOARD_OT_selmarkafter(Operator):
    """Select markers after the current frame"""
    bl_label = "Select Markers After"
    bl_idname = 'boards.selmarkafter'

    def execute(self, context):
        # Get current frame
        curscene = bpy.context.scene.name
        scene = bpy.data.scenes[curscene]
        frame = scene.frame_current

        # Select markers after frame
        select_markers_after(frame)

        return {'FINISHED'}


class STORYBOARD_OT_markall(Operator):
    """Select all markers"""
    bl_label = "Select All Markers"
    bl_idname = 'storyboard.markall'

    def execute(self, context):
        # Get current frame
        curscene = bpy.context.scene.name
        scene = bpy.data.scenes[curscene]
        frame = scene.frame_current

        # Select all markers
        for m in bpy.context.scene.timeline_markers:
            m.select = True

        return {'FINISHED'}


class STORYBOARD_OT_marknone(Operator):
    """Deselect all markers"""
    bl_label = "Deselect All Markers"
    bl_idname = 'storyboard.marknone'

    def execute(self, context):
        # Get current frame
        curscene = bpy.context.scene.name
        scene = bpy.data.scenes[curscene]
        frame = scene.frame_current

        # Deselect all markers
        for m in bpy.context.scene.timeline_markers:
            m.select = False

        return {'FINISHED'}


class STORYBOARD_OT_marktimechange(Operator):
    """Change time duration of selected markers"""
    bl_label = "Marker Time Change"
    bl_idname = 'storyboard.marktimechange'

    time_jump: bpy.props.IntProperty(
        name="Frames per Shot",
        description="Number of frames between markers",
        default=20,
        min=1,
    )

    def execute(self, context):
        # curscene = bpy.context.scene.name
        # scene = bpy.data.scenes[curscene]
        scene = context.scene
        mlist = scene.timeline_markers
        markerlist = sorted(mlist, key=lambda mlist: mlist.frame)
        len_markers = len(markerlist)
        time_dif = 0
        for m, mark in enumerate(markerlist):
            if mark.select and ((m + 1) < len_markers):
                # start shifting
                time_dif = self.time_jump - (markerlist[m + 1].frame - mark.frame)
                # print("SHIFT: ", time_dif)
                for mshift in range((m + 1), len_markers):
                    # print(markerlist[mshift].name)
                    markerlist[mshift].frame = time_dif + markerlist[mshift].frame

        return {'FINISHED'}

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        storyboard = bpy.context.scene.sb_data
        preferences = bpy.context.preferences.addons[__package__].preferences
        # mlist = scene.timeline_markers
        # markerlist = sorted(mlist, key=lambda mlist: mlist.frame)

        row = layout.row()
        row.label(text="Press ESC to abort")
        box = layout.box()
        row = box.row()
        row.label(text="Frames per shot")
        row.prop(self, 'time_jump', text="")
        row = box.row()
        scene_fps = scene.render.fps
        duration = round((self.time_jump / scene_fps), 2)
        row.label(text="Duration (seconds): ")
        row.label(text=str(duration))
        row = box.row()
        row.label(text="Scene FPS: {}".format(scene_fps))

    def invoke(self, context, event):
        scene = bpy.context.scene
        storyboard = bpy.context.scene.sb_data
        preferences = bpy.context.preferences.addons[__package__].preferences
        return context.window_manager.invoke_props_dialog(self)


class STORYBOARD_OT_marknavprev(Operator):
    """Jump to the previous marker in the scene"""
    bl_label = "Marker Nav"
    bl_idname = 'boards.marknavprev'

    def execute(self, context):

        jump_marker(False)   # False is backwards (previous marker)
        update_text_editor()

        return {'FINISHED'}


class STORYBOARD_OT_marknavnext(Operator):
    """Jump to the next marker in the scene"""
    bl_label = "Marker Nav"
    bl_idname = 'boards.marknavnext'

    def execute(self, context):

        jump_marker(True)   # True is forward (next marker)
        update_text_editor()

        return {'FINISHED'}


class STORYBOARD_OT_marknavjump(Operator):
    """Jump to a specific marker in the timeline"""
    bl_label = "Marker Jump"
    bl_idname = 'boards.marknavjump'

    frame: bpy.props.IntProperty(
        name="Frame Number",
        default=1
    )

    def execute(self, context):

        update_text_editor()

        return {'FINISHED'}

    def invoke(self, context, event):
        # if event.ctrl:
        #    print("CTRL Click!!!!")
        bpy.context.scene.frame_current = self.frame

        return self.execute(context)


class STORYBOARD_OT_markerswap(Operator):
    """Swap positions of two markers in the timeline"""
    bl_label = "Marker Swap"
    bl_idname = 'boards.markerswap'

    frame: bpy.props.IntProperty(
        name="Frame Number",
        default=1
    )

    def execute(self, context):

        scene = context.scene
        markerlist = scene.timeline_markers
        markswapper = []
        markframe = 0
        for m in markerlist:
            if m.select:
                markswapper.append(m)
        if len(markswapper) == 2:
            markframe = markswapper[0].frame
            markswapper[0].frame = markswapper[1].frame
            markswapper[1].frame = markframe

        return {'FINISHED'}


class STORYBOARD_OT_deletion(Operator):
    bl_label = "DELETE Board"
    bl_idname = 'boards.deletion'

    def execute(self, context):

        curscene = bpy.context.scene.name
        scene = bpy.data.scenes[curscene]
        scene.timeline_markers.clear()
        del bpy.types.Scene.storyboard

        return {'FINISHED'}


class STORYBOARD_OT_import_images(Operator):
    """Import images for each visible panel"""
    bl_idname = 'import_scene.boards_images'
    bl_label = 'Load Images onto Boards'

    shader_type: EnumProperty(
        name="Shader Type",
        description="Shader Type of Emission or Principled BSDF",
        items=[
            ('EMISSION', "Emission", "Emission type of shader"),
            ('BSDF', "Principled BSDF", "Principled BSD type of shader"),
        ],
        default='EMISSION'
    )

    def execute(self, context):
        storyboard = bpy.context.scene.sb_data
        loaded_images = []
        board_visible = True
        board = 0
        boards = []
        for obj in bpy.data.collections["Storyboard_Panels"].objects:
            boards.append(obj)
        board_count = len(boards)
        abspath = bpy.path.abspath(storyboard.images_path)
        import_path = pathlib.Path(abspath)
        filetypes = ('*.bmp', '*.jpg', '*.jpeg', '*.png', '*.tif', '*.exr')
        for files in filetypes:
            for import_fpath in import_path.glob(files):
                image = bpy.data.images.load(filepath=str(import_fpath))
                loaded_images.append(image)
        for image in loaded_images:
            board_ready = False
            while not board_ready:
                if board < board_count:
                    board_visible = bpy.data.objects[board].visible_get()
                    board_ready = board_visible
                    if not board_visible:
                        board += 1
                else:
                    break

            if not board_ready:
                placetime = find_spacetime(context)
                add_board(placetime[0], placetime[1], placetime[2])
                obj = bpy.context.active_object
                boards.append(obj)
                board_count += 1
                board_visible = True
            mat_name = image.name.split(".")[0]
            # search for existing name and delete
            for mat in bpy.data.materials:
                if mat_name == mat.name:
                    bpy.data.materials.remove(mat)
                    break
            material = bpy.data.materials.new(name=mat_name)
            material.use_nodes = True
            link = material.node_tree.links.new
            tex = material.node_tree.nodes.new('ShaderNodeTexImage')
            tex.location = (-300, 300)
            tex.image = image
            # Principled
            b_shader = material.node_tree.nodes["Principled BSDF"]
            b_shader.location = (0, 180)
            link(b_shader.inputs['Base Color'], tex.outputs['Color'])
            # Emission
            e_shader = material.node_tree.nodes.new('ShaderNodeEmission')
            e_shader.location = (50, 300)
            link(e_shader.inputs['Color'], tex.outputs['Color'])
            if self.shader_type == 'EMISSION':
                matout = material.node_tree.nodes.get('Material Output')
                link(matout.inputs[0], e_shader.outputs[0])
            # update position in boards list
            #  board + board_offset
            boards[board].active_material = material
            board += 1

        return {'FINISHED'}

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)


class STORYBOARD_OT_import_one_image(Operator):
    """Import image onto selected board"""
    bl_idname = 'boards.import_one_image'
    bl_label = 'Load Image onto Single Board'

    shader_type: EnumProperty(
        name="Shader Type",
        description="Shader Type of Emission or Principled BSDF",
        items=[
            ('EMISSION', "Emission", "Emission type of shader"),
            ('BSDF', "Principled BSDF", "Principled BSD type of shader"),
        ],
        default='EMISSION'
    )

    def execute(self, context):
        # Need to write new code for single import
        return {'CANCELLED'}

        storyboard = bpy.context.scene.sb_data
        loaded_images = []
        board_visible = True
        board = 0
        boards = []
        for obj in bpy.data.collections["Storyboard_Panels"].objects:
            boards.append(obj)
        board_count = len(boards)
        abspath = bpy.path.abspath(storyboard.images_path)
        import_path = pathlib.Path(abspath)
        filetypes = ('*.bmp', '*.jpg', '*.jpeg', '*.png', '*.tif', '*.exr')
        for files in filetypes:
            for import_fpath in import_path.glob(files):
                image = bpy.data.images.load(filepath=str(import_fpath))
                loaded_images.append(image)
        for image in loaded_images:
            board_ready = False
            while not board_ready:
                if board < board_count:
                    board_visible = bpy.data.objects[board].visible_get()
                    board_ready = board_visible
                    if not board_visible:
                        board += 1
                else:
                    break

            if not board_ready:
                placetime = find_spacetime(context)
                add_board(placetime[0], placetime[1], placetime[2])
                obj = bpy.context.active_object
                boards.append(obj)
                board_count += 1
                board_visible = True
            mat_name = image.name.split(".")[0]
            # search for existing name and delete
            for mat in bpy.data.materials:
                if mat_name == mat.name:
                    bpy.data.materials.remove(mat)
                    break
            material = bpy.data.materials.new(name=mat_name)
            material.use_nodes = True
            link = material.node_tree.links.new
            tex = material.node_tree.nodes.new('ShaderNodeTexImage')
            tex.location = (-300, 300)
            tex.image = image
            # Principled
            b_shader = material.node_tree.nodes["Principled BSDF"]
            b_shader.location = (0, 180)
            link(b_shader.inputs['Base Color'], tex.outputs['Color'])
            # Emission
            e_shader = material.node_tree.nodes.new('ShaderNodeEmission')
            e_shader.location = (50, 300)
            link(e_shader.inputs['Color'], tex.outputs['Color'])
            if self.shader_type == 'EMISSION':
                matout = material.node_tree.nodes.get('Material Output')
                link(matout.inputs[0], e_shader.outputs[0])
            # update position in boards list
            #  board + board_offset
            boards[board].active_material = material
            board += 1

        return {'FINISHED'}

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)


class STORYBOARD_OT_addfocus(Operator):
    """Add a focal point object for the camera"""
    bl_idname = "boards.addfocus"
    bl_label = "Add Focus Object"
    bl_description = "Add a focal point object for the camera"

    def execute(self, context):
        cam = bpy.context.scene.camera
        if not cam:
            return {'CANCELLED'}
        bpy.ops.object.mode_set(mode='OBJECT')
        # Add cube shaped empty
        bpy.ops.object.empty_add(type='CUBE', align='WORLD', location=(0, 0, 0))
        rfocus = bpy.context.active_object
        bpy.ops.collection.objects_remove_all()
        bpy.data.collections["Storyboard_Cameras"].objects.link(rfocus)
        # Scale down Y axis of empty cube
        rfocus.scale = (1.689, 0.1, 1.0)
        rfocus.location = (cam.location[0], 0, cam.location[2])
        rfocus.name = cam.name + " Focal Point"
        cam.data.dof.focus_object = bpy.data.objects[rfocus.name]
        # Assign to current camera
        elem = cam.data.sb_objects.add()
        elem.name = rfocus.name
        elem.focus = True
        elem.obj = rfocus
        bpy.ops.object.select_all(action='DESELECT')
        bpy.context.view_layer.objects.active = cam
        rfocus.select_set(True)
        bpy.ops.object.parent_set(type='OBJECT', keep_transform=True)
        bpy.ops.object.select_all(action='DESELECT')
        rfocus.select_set(True)
        bpy.context.view_layer.objects.active = rfocus

        return {'FINISHED'}


class STORYBOARD_OT_addtext(Operator):
    """Add a text object"""
    bl_idname = "boards.addtext"
    bl_label = "Add Text"
    bl_description = "Add a text object"

    def execute(self, context):
        cam = bpy.context.scene.camera
        if not cam:
            return {'CANCELLED'}
        if bpy.context.active_object:
            bpy.ops.object.mode_set(mode='OBJECT')
        # Add text object
        bpy.ops.object.text_add(enter_editmode=False, align='WORLD', location=(0, 0, 0))
        text_obj = bpy.context.active_object
        bpy.ops.collection.objects_remove_all()
        bpy.data.collections["Storyboard_Elements"].objects.link(text_obj)
        text_obj.location = (cam.location[0], 0, cam.location[2])
        text_obj.data.align_x = 'CENTER'
        text_obj.rotation_euler[0] = 1.5708
        bpy.ops.object.transforms_to_deltas(mode='ROT')
        text_obj.name = cam.name + " Text"
        # Assign to current camera
        elem = cam.data.sb_objects.add()
        elem.name = text_obj.name
        elem.obj = text_obj
        bpy.ops.object.select_all(action='DESELECT')
        text_obj.select_set(True)
        bpy.context.view_layer.objects.active = text_obj

        return {'FINISHED'}


class STORYBOARD_OT_set_shot_cam(Operator):
    """Set chosen camera as the scene's active camera"""
    # Class based on Camera marker & switcher by Fsiddi
    bl_idname = "cameraselector.set_shot_camera"
    bl_label = "Set Scene Camera"
    bl_description = "Set chosen camera as the scene's active camera"

    hide_others = False

    def execute(self, context):
        chosen_camera = context.active_object
        scene = context.scene

        if self.hide_others:
            for c in [o for o in scene.objects if o.type == 'CAMERA'
                      and o.name != "Storyboard"]:
                c.hide = (c != chosen_camera)
        scene.camera = chosen_camera
        bpy.ops.object.select_all(action='DESELECT')
        chosen_camera.select_set(True)
        bpy.context.view_layer.objects.active = chosen_camera
        update_text_editor()

        return {'FINISHED'}

    def invoke(self, context, event):
        if event.ctrl:
            self.hide_others = True

        return self.execute(context)


classes = (
    STORYBOARD_OT_creation,
    STORYBOARD_OT_conversion,
    STORYBOARD_OT_addition,
    STORYBOARD_OT_append,
    STORYBOARD_OT_deletion,
    STORYBOARD_OT_cursortopanel,
    STORYBOARD_OT_copytopanel,
    STORYBOARD_OT_movetopanel,
    STORYBOARD_OT_viewshotlist,
    STORYBOARD_OT_selmarkafter,
    STORYBOARD_OT_markall,
    STORYBOARD_OT_marknone,
    STORYBOARD_OT_marknavprev,
    STORYBOARD_OT_marknavnext,
    STORYBOARD_OT_marknavjump,
    STORYBOARD_OT_marktimechange,
    STORYBOARD_OT_markerswap,
    STORYBOARD_OT_find,
    STORYBOARD_OT_addelement,
    STORYBOARD_OT_pickelement,
    STORYBOARD_OT_pickallelements,
    STORYBOARD_OT_unlinkelement,
    STORYBOARD_OT_fastdraw,
    STORYBOARD_OT_stopdraw,
    STORYBOARD_OT_camprev,
    STORYBOARD_OT_camnext,
    STORYBOARD_OT_rearrange,
    STORYBOARD_OT_centerstoryboard,
    STORYBOARD_OT_storyboardviews,
    STORYBOARD_OT_sbviewsmenu,
    STORYBOARD_OT_sbcamsave,
    STORYBOARD_OT_swapshot,
    STORYBOARD_OT_updatetexteditor,
    STORYBOARD_OT_import_images,
    STORYBOARD_OT_import_one_image,
    STORYBOARD_OT_addfocus,
    STORYBOARD_OT_addtext,
    STORYBOARD_OT_set_shot_cam,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in classes:
        bpy.utils.unregister_class(cls)
