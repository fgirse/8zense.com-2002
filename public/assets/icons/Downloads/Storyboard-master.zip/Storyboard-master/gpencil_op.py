import bpy
#from bpy.props import StringProperty, BoolProperty, EnumProperty
from bpy.types import Operator


def make_gp_mat(colorname, s_bool, s_rgba, f_bool, f_rgba):
    # Create material for grease pencil
    if colorname in bpy.data.materials.keys():
        gp_mat = bpy.data.materials[colorname]
    else:
        gp_mat = bpy.data.materials.new(colorname)

    if not gp_mat.is_grease_pencil:
        bpy.data.materials.create_gpencil_data(gp_mat)
        if s_bool:
            gp_mat.grease_pencil.color = s_rgba
        if f_bool:
            gp_mat.grease_pencil.fill_color = f_rgba
    return gp_mat


class STORYBOARD_OT_add_basic(bpy.types.Operator):
    """Create a blank Grease Pencil object with materials"""
    bl_idname = "gpencil.addbasic"
    bl_label = "Add Basic Grease Pencil"
    bl_description = "Create a blank Grease Pencil object with materials"

    def execute(self, context):

        context = bpy.context
        space = context.space_data
        cam = bpy.context.scene.camera
        storyboard = bpy.context.scene.sb_data
        preferences = bpy.context.preferences.addons[__package__].preferences
        coll_name = "Storyboard_Elements"
        gpname = "GPencil"
        if cam:
            gpname = cam.name + " GPencil"

        # stroke_bool = True
        # fill_bool = False
        # gp_mat = make_gp_mat("Black", stroke_bool,
        #                      (0.0, 0.0, 0.0, 1), fill_bool, (0.0, 0.0, 0.0, 1))

        # Add grease pencil object
        gp_data = bpy.data.grease_pencils.new(gpname)
        gp_ob = bpy.data.objects.new(gpname, gp_data)
        print(gp_ob.location)
        if cam:
            gp_ob.location[0] = cam.location[0]
            gp_ob.location[2] = cam.location[2]
        # context.scene.collection.objects.link(gp_ob)
        # bpy.ops.collection.objects_remove_all()
        if coll_name in bpy.data.collections:
            bpy.data.collections[coll_name].objects.link(gp_ob)
        else:
            bpy.data.collections["Collection"].objects.link(gp_ob)
        if space.local_view:
            gp_ob.local_view_set(space, True)

        for ob in context.selected_objects:
            ob.select_set(False)
        gp_ob.select_set(True)
        context.view_layer.objects.active = gp_ob
        if storyboard.created:
            elem = cam.data.sb_objects.add()
            elem.name = gp_ob.name
            elem.obj = gp_ob
        bpy.ops.object.mode_set(mode='PAINT_GPENCIL')

        # Add GP layers
        if preferences.gplayer_fav5_bool:
            gplayer_name = preferences.gplayer_fav5_name
            layer = gp_data.layers.new(gplayer_name, set_active=True)

        if preferences.gplayer_fav4_bool:
            gplayer_name = preferences.gplayer_fav4_name
            layer = gp_data.layers.new(gplayer_name, set_active=True)

        if preferences.gplayer_fav3_bool:
            gplayer_name = preferences.gplayer_fav3_name
            layer = gp_data.layers.new(gplayer_name, set_active=True)

        if preferences.gplayer_fav2_bool:
            gplayer_name = preferences.gplayer_fav2_name
            layer = gp_data.layers.new(gplayer_name, set_active=True)

        if preferences.gplayer_fav1_bool:
            gplayer_name = preferences.gplayer_fav1_name
            layer = gp_data.layers.new(gplayer_name, set_active=True)

        if preferences.gplayer_fav_bool:
            gplayer_name = preferences.gplayer_fav_name
            layer = gp_data.layers.new(gplayer_name, set_active=True)

        # New make_gp_mat parameters
        # make_gp_mat(colorname, s_bool, s_rgba, f_bool, f_rgba)
        if preferences.mat_blk_bool:
            stroke_bool = True
            fill_bool = False
            gp_mat = make_gp_mat("Black", stroke_bool,
                                 (0.0, 0.0, 0.0, 1), fill_bool, (0.0, 0.0, 0.0, 1))
            gp_data.materials.append(gp_mat)

        if preferences.mat_gry_bool:
            stroke_bool = True
            fill_bool = False
            gp_mat = make_gp_mat("Grey Darkest", stroke_bool, (0.019,
                                                               0.019, 0.019, 1), fill_bool, (0.019, 0.019, 0.019, 1))
            gp_data.materials.append(gp_mat)
            gp_mat = make_gp_mat("Grey Dark", stroke_bool, (0.072,
                                                            0.072, 0.072, 1), fill_bool, (0.072, 0.072, 0.072, 1))
            gp_data.materials.append(gp_mat)
            gp_mat = make_gp_mat("Grey Mid", stroke_bool, (0.169,
                                                           0.169, 0.169, 1), fill_bool, (0.169, 0.169, 0.169, 1))
            gp_data.materials.append(gp_mat)
            gp_mat = make_gp_mat("Grey Light", stroke_bool, (0.319,
                                                             0.319, 0.319, 1), fill_bool, (0.319, 0.319, 0.319, 1))
            gp_data.materials.append(gp_mat)
            gp_mat = make_gp_mat("Grey Lightest", stroke_bool, (0.515,
                                                                0.515, 0.515, 1), fill_bool, (0.515, 0.515, 0.515, 1))
            gp_data.materials.append(gp_mat)

        if preferences.mat_wht_bool:
            stroke_bool = True
            fill_bool = False
            gp_mat = make_gp_mat(
                "White", stroke_bool, (1.0, 1.0, 1.0, 1), fill_bool, (1.0, 1.0, 1.0, 1))
            gp_data.materials.append(gp_mat)

        if preferences.mat_fav_bool:
            gpnam = preferences.mat_fav_name
            strkb = preferences.mat_fav_stkbool
            strkc = preferences.mat_fav_stkcolor
            fillb = preferences.mat_fav_fillbool
            fillc = preferences.mat_fav_fillcolor
            # make_gp_mat(colorname, s_bool, s_rgba, f_bool, f_rgba)
            gp_mat = make_gp_mat(gpnam, strkb, strkc, fillb, fillc)
            gp_data.materials.append(gp_mat)

        if preferences.mat_fav1_bool:
            gpnam = preferences.mat_fav1_name
            strkb = preferences.mat_fav1_stkbool
            strkc = preferences.mat_fav1_stkcolor
            fillb = preferences.mat_fav1_fillbool
            fillc = preferences.mat_fav1_fillcolor
            gp_mat = make_gp_mat(gpnam, strkb, strkc, fillb, fillc)
            gp_data.materials.append(gp_mat)

        if preferences.mat_fav2_bool:
            gpnam = preferences.mat_fav2_name
            strkb = preferences.mat_fav2_stkbool
            strkc = preferences.mat_fav2_stkcolor
            fillb = preferences.mat_fav2_fillbool
            fillc = preferences.mat_fav2_fillcolor
            gp_mat = make_gp_mat(gpnam, strkb, strkc, fillb, fillc)
            gp_data.materials.append(gp_mat)

        if preferences.mat_fav3_bool:
            gpnam = preferences.mat_fav3_name
            strkb = preferences.mat_fav3_stkbool
            strkc = preferences.mat_fav3_stkcolor
            fillb = preferences.mat_fav3_fillbool
            fillc = preferences.mat_fav3_fillcolor
            gp_mat = make_gp_mat(gpnam, strkb, strkc, fillb, fillc)
            gp_data.materials.append(gp_mat)

        # Draw, using the material defined
        bpy.ops.gpencil.draw(wait_for_input=False)

        # Assign the material to the grease pencil for drawing
        bpy.context.object.active_material_index = 0       # <===== TRY THIS

        bpy.context.space_data.show_region_tool_header = True
        # SURFACE does NOT work well with boards
        # origin of board best
        #bpy.context.scene.tool_settings.gpencil_stroke_placement_view3d = 'SURFACE'

        return {'FINISHED'}


classes = (
    STORYBOARD_OT_add_basic,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in classes:
        bpy.utils.unregister_class(cls)
